<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    include 'connect-database.php';
    
    $id = $_POST["Article_id"];

    $stmt = $pdo->prepare('SELECT * FROM articles WHERE article_id = ?');
    $stmt->execute([$id]);
    $article = $stmt->fetch(PDO::FETCH_ASSOC);

    session_start();
    $_SESSION["Edit_article_ID"] = $id;
    $_SESSION["Edit_article"] = $article;
    header("Location: Write_article.php");
    exit;

}