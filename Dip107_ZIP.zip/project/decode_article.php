<?php
    $user_id = $article["user_id"];
    $date_published = $article["date_published"];
    $content = $article["content"];
    $content = strval($content);

    /*get publisher name*/
    $stmt = $pdo->prepare('SELECT name FROM accounts WHERE id = ?');
    $stmt->execute([$user_id]);
    $user_name = $stmt->fetch(PDO::FETCH_ASSOC);
    $user_name = $user_name["name"];

    /*format date*/
    $date_published = date(' D Y-m-d', strtotime($date_published));


    /*decode content*/
    $Docoded_content = (explode('!$$*$%%.$',$content));

    $Format = (explode(',',$Docoded_content[0]));
    $content = (explode('!!&&^#&&^^.!',$Docoded_content[1]));

?>