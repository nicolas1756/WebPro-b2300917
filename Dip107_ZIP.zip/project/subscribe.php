<?php

$curl = curl_init();
$email = 'nicolas8280yeh@gmail.com';

curl_setopt_array($curl, [
  CURLOPT_URL => "https://stoplight.io/mocks/beehiiv/v2/104190750/publications/pub_3f3d93d3-b94b-4e8d-8a03-b2b5a04f1730/subscriptions",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode([
    'email' => $email,
    'reactivate_existing' => true,
    'send_welcome_email' => true,
  ]),
  CURLOPT_HTTPHEADER => [
    "Accept: application/json",
    "Authorization: Bearer 3zecQ2g21Wl9H20Lz5pHpcx8lgcKN3hO6CKkY9dzyTkd7Q49fKOZq4Silli5DSuo",
    "Content-Type: application/json",
    "Prefer: code=200"
  ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
