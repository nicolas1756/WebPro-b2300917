<?php
include 'connect-database.php';


$post_id = $_POST['post_id'];

$sql = "DELETE FROM post_comments WHERE post_id = ?";
$statement = $pdo->prepare($sql);
$statement->execute([$post_id]);

$sql = "DELETE FROM post_ratings WHERE post_id = ?";
$statement = $pdo->prepare($sql);
$statement->execute([$post_id]);

$sql = "DELETE FROM post_views WHERE post_id = ?";
$statement = $pdo->prepare($sql);
$statement->execute([$post_id]);

$sql = "DELETE FROM posts WHERE post_id = ?";
$statement = $pdo->prepare($sql);
$statement->execute([$post_id]);


    session_start();
    $_SESSION["status"] = "<script>alert('post successfully removed.');</script>";
    header("Location: Forum.php");
    exit;


?>