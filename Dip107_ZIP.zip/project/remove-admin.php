<?php
include 'connect-database.php';

$id = $_POST['account_id'];

$sql = "UPDATE accounts SET role = ? WHERE id = ?";
$statement = $pdo->prepare($sql);
$statement->execute(["Standard", $id]);

session_start();
$_SESSION["status"] = "<script>alert('admin successfully removed.');</script>";
header("Location: admin-panel.php");
exit;

?>