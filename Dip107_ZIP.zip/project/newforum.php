<?php

session_start();

if (isset($_SESSION['status'])) { //send error message
  echo $_SESSION['status'];
  unset($_SESSION['status']);
}

if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  include 'connect-database.php';
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}

if($user_role == 'unregistered'){
    header("Location: Profile.php");
}
?>

<!DOCTYPE html>

<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,minimum-scale=1">
		<title>Create forum</title>
        <script type = "text/javascript" src="sidebar.js"></script>  
        <script type = "text/javascript" src="add-textArea.js"></script> 
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
		<link href="colour.css" rel="stylesheet" type="text/css">
     <!-- Google tag (gtag.js) -->
     <script async src="https://www.googletagmanager.com/gtag/js?id=G-7YY8RYJRBZ"></script>
      <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-7YY8RYJRBZ');
      </script>
	</head>
	<body>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
        <section class="menu">
            <div class="menu-container">  
                <nav class="navbar">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li class="highlighted-menu"><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </nav>
                
                <nav class="Profile" href="profile.php">
                    <a href="profile.php" class="sign-in" ><?=$user_name?></a>
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                </nav>
            </div>
            
            <div class="menu-container-mobile"> 
                <div class = "pop-out-menu">
                    <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                </div>
                
                <div>
                    <nav class="Profile-mobile" href="profile.php">
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                    </nav>
                </div>
            </div>

            <div id ="fix-sidebar">
              <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li class="highlighted-menu"><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
            
        </section>

        <section class="margin">
            <div class= 'forum_post_submit'>
                <div><button onclick="if (confirm('This will delete the draft. Would you still like to proceed?')) { window.history.back(); } return false;">Exit</button></div>
                <div><button onclick="Post()">Post</button></div>
            </div>

            <form action = 'add_forum.php' class="Forum_post_add" id= 'Post_content' method = 'post'>
                <textarea name="Title" id= "Title_mandatory" class="Title" placeholder = "Title"></textarea>
                <textarea name="body" id= "body" class="body" placeholder = "Write body here"></textarea>
                <script>textAreaSettings()</script>
            </form>     
        </section>

        <script>
            function Post() {
                document.getElementById("Post_content").submit()
            }
        </script>
 
        <footer>
            <div class="footer-container">
              <nav class="footer-left">
                <ul>
                  <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
                </ul>
              </nav>
              <div class="footer-right">
                <p>© 2024 Help+</p>
                <a href="about-page.php">Credits</a>
              </div>
            </div>
          </footer>
          
          
    </body> 
</html>