const textBox = document.getElementById('input');
const editButton = document.getElementById('edit-button');
const saveButton = document.getElementById('save-button');

textBox.contentEditable = 'false'; // Initially not editable

editButton.addEventListener('click', () => {
  textBox.contentEditable = 'true'; // Make editable on click
  textBox.focus(); // Set focus to textbox
  saveButton.disabled = false; // Enable save button
});

saveButton.addEventListener('click', () => {
  textBox.contentEditable = 'false'; // Disable editing on save
  saveButton.disabled = true; // Disable save button again
  // Here you can add logic to save the edited text (e.g., send to server)
});