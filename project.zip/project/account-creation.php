<!DOCTYPE html>

<html>
    <head>
        <title>Sign in</title>
        <link rel="stylesheet" href="colour.css">
    </head>
    
    <body class="sign-in-page">
        <div class="sign-in-container">
            <div>
                <form class="signin-form" action="" method="post">
                    <div class="sex-input">
                      <label for="sex">Sex:</label>
                      <input type="radio" id="sex" name="sex" value="male" required> Male
                      <input type="radio" id="sex" name="sex" value="female" required> Female
                    </div>
                    <div class="birth-input">
                      <label for="birthdate">Birthday: </label>
                      <input type="date" id="birthdate" name="birthdate">
                    </div>
                    <button type="submit">Submit</button>
                </form>
            </div>
        </div>
    </body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    function debug_to_console($data) {
        $output = $data;
        if (is_array($output))
            $output = implode(',', $output);
    
        echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
    }
    
    include 'connect-database.php';
    
    session_start();
    $profile = $_SESSION['profile'];
    $birthdate = $_POST['birthdate'];
    $Sex = $_POST['sex'];
    $Role = 'Standard';
    $google_name_parts = [];
    $google_name_parts[] = isset($profile['given_name']) ? preg_replace('/[^a-zA-Z0-9]/s', '', $profile['given_name']) : '';
    $google_name_parts[] = isset($profile['family_name']) ? preg_replace('/[^a-zA-Z0-9]/s', '', $profile['family_name']) : '';
    
    $stmt = $pdo->prepare('INSERT INTO accounts (email, name, picture, registered, method, sex, birthdate, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([ $profile['email'], implode(' ', $google_name_parts), isset($profile['picture']) ? $profile['picture'] : '', date('Y-m-d H:i:s'), 'google', $Sex, $birthdate, $Role]);
    $id = $pdo->lastInsertId();
    session_destroy();
    // Authenticate the account
    session_regenerate_id();
    $_SESSION['google_loggedin'] = TRUE;
    $_SESSION['google_id'] = $id;
    // Redirect to profile page
    header('Location: profile.php');
    exit;
}