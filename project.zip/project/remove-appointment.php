<?php
include 'connect-database.php';

$appointment_id = $_POST["appointment_id"];

$sql = "DELETE FROM appointments WHERE appointment_id = ?";
$statement = $pdo->prepare($sql);
$statement->execute([$appointment_id]);

$rowsAffected = $statement->rowCount();

if ($rowsAffected === 0) {
    session_start();
    $_SESSION["status"] = "<script>alert('Appointment was not deleted. Please try again.');</script>";
    header("Location: appointments.php");
    exit;
} else {
    session_start();
    $_SESSION["status"] = "<script>alert('Appointment successfully deleted.');</script>";
    header("Location: appointments.php");
    exit;
}
?>