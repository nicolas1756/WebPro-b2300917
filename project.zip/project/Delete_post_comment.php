<?php
include 'connect-database.php';

$comment_id = $_POST['comment_id'];
$post_id = $_POST['post_id'];

$sql = "DELETE FROM post_comments WHERE comment_id = ?";
$statement = $pdo->prepare($sql);
$statement->execute([$comment_id]);

echo"
<form action='View_forum_post.php' id = 'form' method = 'post'>
    <input type='text' name='post_id' value = '$post_id' style = 'display:none'>
</form>

<script>
  document.getElementById('form').submit();
</script>
";

?>