<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    include 'connect-database.php';
    
    $id = $_POST["doctor_id"];

    $sql = "DELETE FROM doctors WHERE user_id = ?";
    $statement = $pdo->prepare($sql);
    $statement->execute([$id]);

    if ($rowsAffected === 0) {
        session_start();
        $_SESSION["status"] = "<script>alert('doctor was not removed. Please try again.');</script>";
        header("Location: admin-panel.php");
        exit;
    }

    else{
        $sql = "UPDATE accounts SET role = ? WHERE id = ?";
        $statement = $pdo->prepare($sql);
        $statement->execute(["Standard", $id]);

        if ($rowsAffected === 0) {
            session_start();
            $_SESSION["status"] = "<script>alert('doctor was not removed. Please try again.');</script>";
            header("Location: admin-panel.php");
            exit;
        }

        else{
            session_start();
            $_SESSION["status"] = "<script>alert('doctor successfully removed.');</script>";
            header("Location: admin-panel.php");
            exit;
        }
    }

}