<?php

session_start();

if(!isset($_GET['Radio_sort'])) {
  $_SESSION['Searchquery'] = "";
} 

if (isset($_SESSION['status'])) { //send error message
  echo $_SESSION['status'];
  unset($_SESSION['status']);
}


if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  include 'connect-database.php';
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}

include 'reset_trending.php';
?>

<!DOCTYPE html>

<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,minimum-scale=1">
		<title>Forum</title>
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
		<link href="colour.css" rel="stylesheet" type="text/css">
     <!-- Google tag (gtag.js) -->
     <script async src="https://www.googletagmanager.com/gtag/js?id=G-7YY8RYJRBZ"></script>
      <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-7YY8RYJRBZ');
      </script>
	</head>
	<body>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
        <section class="menu">
            <div class="menu-container">  
                <nav class="navbar">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li class="highlighted-menu"><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </nav>
                
                <nav class="Profile" href="profile.php">
                    <a href="profile.php" class="sign-in" ><?=$user_name?></a>
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                </nav>
            </div>
            
            <div class="menu-container-mobile"> 
                <div class = "pop-out-menu">
                    <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                </div>
                
                <div>
                    <nav class="Profile-mobile" href="profile.php">
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                    </nav>
                </div>
            </div>

            <div id ="fix-sidebar">
              <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li class="highlighted-menu"><a href="Forum.html">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
            
        </section>

        <section class="margin">
          <div class = 'my_forum_options_container'>
            <div><a class = 'my_post_button'href="My_posts.php">My posts</a></div>
            <div><a href="newforum.php">New post</a></div>
          </div>
          
          <form action="" method = 'POST'>
            <div class= 'Forum_search_container'>
                <div><input type="text" name = 'search_term' placeholder ='Search here'></div>
                <div><button type = 'submit'>Enter</button></div>
            </div>
          </form>
          
          <div class = 'forum_options_container'>
            <div>
              <form method = 'get' id = 'sort_form'>
                  <div class= 'sort_container'>
                      <div class='sort'>
                          <input type='radio' name='Radio_sort' id = 'Latest' value='Latest' >
                          <label for='Latest'>Latest</label>
                      </div>
                      <div class='sort'>
                          <input type='radio' name='Radio_sort' id = 'Most_viewed' value='Most_viewed' >
                          <label for='Most_viewed'>Most viewed</label>
                      </div>
                      <div class='sort'>
                          <input type='radio' name='Radio_sort' id = 'Popular'value='Popular'>
                          <label for='Popular'>Popular</label>
                      </div>
                  </div>
              </form>
            </div>

            <script>
                const form = document.getElementById('sort_form');
                const SortGroup = document.getElementsByName('Radio_sort');

                form.addEventListener('click', (event) => {
                // Check if any radio button is checked
                const isChecked = [...SortGroup].some(radio => radio.checked);

                // Submit the form if a radio button is checked
                if (isChecked) {
                    form.submit();
                }
                });
            </script>
          </div>

          <!-- View posts -->

        <section class = 'view_forum_post'>
          <?php
            @$Searchquery = $_SESSION['Searchquery'];
            if ($_SERVER['REQUEST_METHOD'] === 'POST'){
              @$_SESSION['Searchquery'] = $_POST['search_term'];
              $Searchquery = $_SESSION['Searchquery'];
            }
                
            if ($_SERVER['REQUEST_METHOD'] === 'GET'){
              @$Sort = $_GET['Radio_sort'];

              if ($Sort == 'Most_viewed') {
                  $_SESSION['SortStatus'] = 'Most_viewed';
              }
              elseif ($Sort == 'Popular') {
                  $_SESSION['SortStatus'] = 'Popular';
              }
              else {
                  $_SESSION['SortStatus'] = 'Latest';
              }

            }
            else{
                $_SESSION['SortStatus'] = 'Latest';
            }

            if ($_SESSION['SortStatus'] == 'Most_viewed') {
                $stmt = $pdo->prepare('SELECT posts.*, post_views.View_counter FROM posts INNER JOIN post_views ON posts.post_id = post_views.post_id WHERE (content LIKE ? OR date_published LIKE ?) ORDER BY post_views.View_counter desc');
                $stmt->execute(["%$Searchquery%", "%$Searchquery%"]);
                $posts = $stmt->fetchall(PDO::FETCH_ASSOC);
            }
            elseif ($_SESSION['SortStatus'] == 'Popular') {
              $stmt = $pdo->prepare('SELECT posts.*, post_views.trending_counter FROM posts INNER JOIN post_views ON posts.post_id = post_views.post_id WHERE (content LIKE ? OR date_published LIKE ?) ORDER BY post_views.trending_counter desc');
              $stmt->execute(["%$Searchquery%", "%$Searchquery%"]);
              $posts = $stmt->fetchall(PDO::FETCH_ASSOC);
            }
            else
            {
                $stmt = $pdo->prepare('SELECT * FROM posts WHERE (content LIKE ? OR date_published LIKE ?) ORDER BY date_published desc;');
                $stmt->execute(["%$Searchquery%", "%$Searchquery%"]);
                $posts = $stmt->fetchall(PDO::FETCH_ASSOC);
            }

            foreach($posts as $post){
              $post_id = $post['post_id'];
              $UserId = $post['user_id'];
              $DatePublished = $post['date_published'];
              $DatePublished = date('h:i A m/d/y', strtotime($DatePublished));
              $content = $post['content'];
              
              $stmt = $pdo->prepare('SELECT View_counter FROM post_views WHERE post_id = ?');
              $stmt->execute([$post_id]);
              $view_count = $stmt->fetch(PDO::FETCH_ASSOC);
              $views = $view_count['View_counter'];

              $content = (explode('!$$*$%%.$',$content));
              $Title = $content[0];
              $Body = $content[1];

              $Body = strlen($Body) > 80 ? substr($Body,0,80)."..." : $Body;
              
              $stmt = $pdo->prepare('SELECT picture, name FROM accounts WHERE id = ?');
              $stmt->execute([$UserId]);
              $account_details = $stmt->fetch(PDO::FETCH_ASSOC);

              $account_name = $account_details['name'];
              $account_picture = $account_details['picture'];

              echo "<div><form action='View_forum_post.php' method = 'post' class= 'forum_post_container'> 
                      <input type='text' name='post_id' value = '$post_id' style = 'display:none'>
                      <button type = 'submit' class = 'forum_post_background'>
                          <div class = 'post_picture_container'>
                              <div><img src='$account_picture' alt=''></div>
                              <div>$account_name</div>
                          </div>
                          
                          <p class = 'H3'>$Title</p>
                          <p class = 'Body'>$Body</p>

                          <div class = 'post_view_container'>
                              <div>Views: $views</div>
                              <div>$DatePublished</div>
                          </div>
                      </button>
                    </form></div>
                    ";
            }


          ?>
        </section>

        </section>
 
        <footer>
            <div class="footer-container">
              <nav class="footer-left">
                <ul>
                  <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
                </ul>
              </nav>
              <div class="footer-right">
                <p>© 2024 Help+</p>
                <a href="about-page.php">Credits</a>
              </div>
            </div>
          </footer>
          
          
    </body> 
</html>