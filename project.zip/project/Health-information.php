<?php
// Initialize the session - is required to check the login state.

session_start();

if(!isset($_GET['Radio_sort'])) { /*clear search results*/
    $_SESSION['Searchquery'] = "";
  } 

if (isset($_SESSION['status'])) {
    echo $_SESSION['status'];
    unset($_SESSION['status']);
}

if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  include 'connect-database.php';
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}

include 'reset_trending.php';
?>

<!DOCTYPE html>
<html>
	<head>
        <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-7YY8RYJRBZ"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-7YY8RYJRBZ');
        </script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,minimum-scale=1">
		<title>Health information</title>
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
		<link href="colour.css" rel="stylesheet" type="text/css">
	</head>
	<body>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
        <section class="menu">
            <div class="menu-container">
                <nav class="navbar">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li class="highlighted-menu"><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </nav>
                
                <nav class="Profile" href="profile.php">
                    <a href="profile.php" class="sign-in"><?=$user_name?></a>
                    <a href="profile.php"><img src="<?=$user_picture?>"class="profile-pic"></a>
                </nav>
            </div>

            <div class="menu-container-mobile"> 
                <div class = "pop-out-menu">
                    <img id = "menu-icon-mobile" onclick="sidebar()"src="Images\burger-menu.png"/>
                </div>
                
                <div>
                    <nav class="Profile-mobile" href="profile.php">
                    <a href="profile.php"><img src="<?=$user_picture?>"class="profile-pic"></a>
                    </nav>
                </div>
            </div>
            <div id ="fix-sidebar">
              <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li class="highlighted-menu"><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
        </section>

		<section class="margin">
            <?php
                if ($user_role == "@%^198278ADm1n!@#$*" or $user_role == "$$66^^D0cT0R&&77"){
                    echo "<a href='My_articles.php' class='My_articles_button'>Manage articles</a>"; 
                }
            ?>
            <div class = "search-article-container">
                <div class = 'Past_searches_article'>
                    <?php
                        ob_start();
                        if (isset($_COOKIE["search_history"])) {
                            $searchHistory = $_COOKIE["search_history"];

                            $searchHistory = (explode(',',$searchHistory));
                            echo "<ul><strong>History:</strong></ul>";
                            foreach($searchHistory as $search){
                                if($search == ""){
                                    echo "<ul> </ul>";
                                }
                                else{
                                    echo "<form action='' method='post'>";
                                        echo "<input type='text' name='search_term' value='$search' style = 'display: none'>";
                                        echo "<button type='submit'>$search</button>";
                                    echo "</form>";
                                }
                            }
                        } else {
                            echo "<ul><strong>History:</strong></ul>";
                            echo "<ul>No search history.</ul>";
                            echo "<ul> </ul>";
                            echo "<ul> </ul>";
                            echo "<ul> </ul>";
                        }
                    ?>
                </div>
                <div class = 'search_bar_article'>
                    <form action="" method="post">
                        <div><input type="text" name="search_term" id="" placeholder='Search here'></div>
                        <div><button type ='submit'>Search</button></div>
                    </form>
                </div>
            </div>
            

            <form method = 'get' id = 'sort_form'>
                <div class= 'sort_container'>
                    <div class='sort'>
                        <input type='radio' name='Radio_sort' id = 'Latest' value='Latest' >
                        <label for='Latest'>Latest</label>
                    </div>
                    <div class='sort'>
                        <input type='radio' name='Radio_sort' id = 'Most_viewed' value='Most_viewed' >
                        <label for='Most_viewed'>Most viewed</label>
                    </div>
                    <div class='sort'>
                        <input type='radio' name='Radio_sort' id = 'Popular'value='Popular'>
                        <label for='Popular'>Popular</label>
                    </div>
                </div>
            </form>

            <script>
                const form = document.getElementById('sort_form');
                const SortGroup = document.getElementsByName('Radio_sort');

                form.addEventListener('click', (event) => {
                // Check if any radio button is checked
                const isChecked = [...SortGroup].some(radio => radio.checked);

                // Submit the form if a radio button is checked
                if (isChecked) {
                    form.submit();
                }
                });
            </script>


            <?php
            @$Searchquery = $_SESSION['Searchquery'];
            if ($_SERVER['REQUEST_METHOD'] === 'POST'){
                @$_SESSION['Searchquery'] = $_POST['search_term'];
                $Searchquery = $_SESSION['Searchquery'];
                if($Searchquery != ""){ /*only safe in history if search is not empty*/

                    $cookieName = "search_history";
                    $maxSearches = 4;

                    ob_start();

                    // Access existing cookie value (or create empty string if not set)
                    if (isset($_COOKIE[$cookieName])) {
                        $searchHistory = $_COOKIE[$cookieName];
                        } else {
                        $searchHistory = "";
                        }

                        // Convert existing history to array and add new search
                        $searchHistoryArray = explode(",", $searchHistory);
                        array_unshift($searchHistoryArray, $Searchquery);

                        $searchHistoryArray = array_slice($searchHistoryArray, 0, $maxSearches);

                        $updatedSearchHistory = implode(",", $searchHistoryArray);

                        $expirationTime = time() + (60 * 60 * 24 * 30);

                        setcookie($cookieName, $updatedSearchHistory, $expirationTime, "/"); 
                }
                
            }

                
                if ($_SERVER['REQUEST_METHOD'] === 'GET'){
                    @$Sort = $_GET['Radio_sort'];
    
                    if ($Sort == 'Most_viewed') {
                        $_SESSION['SortStatus'] = 'Most_viewed';
                    }
                    elseif ($Sort == 'Popular') {
                        $_SESSION['SortStatus'] = 'Popular';
                    }
                    else {
                        $_SESSION['SortStatus'] = 'Latest';
                    }

                }
                else{
                    $_SESSION['SortStatus'] = 'Latest';
                }

                if ($_SESSION['SortStatus'] == 'Most_viewed') {
                    $stmt = $pdo->prepare('SELECT articles.*, article_views.view_counter FROM articles INNER JOIN article_views ON articles.article_id = article_views.article_id WHERE (content LIKE ? OR date_published LIKE ?) ORDER BY article_views.view_counter desc');
                    $stmt->execute(["%$Searchquery%", "%$Searchquery%"]);
                    $articles = $stmt->fetchall(PDO::FETCH_ASSOC);
                }
                elseif ($_SESSION['SortStatus'] == 'Popular') {
                    $stmt = $pdo->prepare('SELECT articles.*, article_views.trending_counter FROM articles INNER JOIN article_views ON articles.article_id = article_views.article_id WHERE (content LIKE ? OR date_published LIKE ?) ORDER BY article_views.trending_counter desc');
                    $stmt->execute(["%$Searchquery%", "%$Searchquery%"]);
                    $articles = $stmt->fetchall(PDO::FETCH_ASSOC);
                }
                else
                {
                    $stmt = $pdo->prepare('SELECT * FROM articles WHERE (content LIKE ? OR date_published LIKE ?) ORDER BY date_published desc;');
                    $stmt->execute(["%$Searchquery%", "%$Searchquery%"]);
                    $articles = $stmt->fetchall(PDO::FETCH_ASSOC);
                }

                echo "<div class='news-container'>";
                foreach($articles as $article){

                    include 'decode_article.php';
    
                    $article_id = $article['article_id'];
                    $title = $content[0];

                    $stmt = $pdo->prepare('SELECT view_counter FROM article_views WHERE article_id = ?');
                    $stmt->execute([$article_id]);
                    $view_count = $stmt->fetch(PDO::FETCH_ASSOC);
                    $view_count = $view_count['view_counter'];

                    $utm_source = "Health_information";
                    $utm_medium = "Organic";
                    $utm_campaign = "Article";
                    $utm_content = "$title@$article_id";
                    $base_url = "View-article.php";
                    $utm_string = "?utm_source=".$utm_source."&utm_medium=".$utm_medium."&utm_campaign=".$utm_campaign."&utm_content=".$utm_content;
                    $final_url = $base_url . $utm_string;

                    echo "<div class = 'trending-post'>";
                    echo "<div class = 'post-seperator'><div><h2>$title</h2></div>";
                    echo "<div><div class='trending_container'>";
                      echo "<div>Views:$view_count<br>$date_published</div>";
                      
                      echo "<div>";
                        echo "<form action='$final_url' method='post'>";
                            echo "<input type='text' name='Article_id' value='$article_id' style = 'display: none'>";
                            echo "<button type='submit' class = 'Read_article_button'>Read more</button>";
                        echo "</form>";
                      echo "</div>";
                  echo "</form>";
                    echo "</div></div></div>";
                echo "</div>";
                    
                }

                echo "</div>";


            ?>
        </section>

        <footer>
            <div class="footer-container">
              <nav class="footer-left">
                <ul>
                  <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
                </ul>
              </nav>
              <div class="footer-right">
                <p>© 2024 Help+</p>
                <a href="about-page.php">Credits</a>
              </div>
            </div>
        </footer>
	</body>
</html>