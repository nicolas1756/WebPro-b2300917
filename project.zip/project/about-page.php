<?php

session_start();

if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>About page</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="colour.css">
         <!-- Google tag (gtag.js) -->
         <script async src="https://www.googletagmanager.com/gtag/js?id=G-7YY8RYJRBZ"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-7YY8RYJRBZ');
        </script>
    </head>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
        <section class="menu">
            <div class="menu-container">  
                
              <nav class="navbar">
                  <ul>
                      
                    <li><a href="Home.php">Home</a></li>
                    <li><a href="Health-information.php">Health information</a></li>
                    <li><a href="Forum.php">Forum</a></li>
                    <li><a href="Newsletter.php">Newsletter</a></li>
                    <li class="highlighted-menu"><a href="about-page.php">About us</a></li>
                  </ul>
              </nav>
              
              <nav class="Profile" href="profile.php">
                  <a href="profile.php" class="sign-in" ><?=$user_name?></a>
                  <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
              </nav>

            </div>

            <div class="menu-container-mobile"> 
              <div class = "pop-out-menu">
                  <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
              </div>
              
              <div>
                  <nav class="Profile-mobile" href="profile.php">
                  <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                  </nav>
              </div>
            </div>

            <div id ="fix-sidebar">
              <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li class="highlighted-menu"><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
              
        </section>


        <section class="margin">
          <section class="about_page">
            <p class = 'H1'>Our purpose</p>
            <p class = 'body'>The purpose of this website is to provide accurate medical information for everyone, regardless of age or technical expertise. To achieve this, an easy-to-navigate design is crucial.  This means a clear and concise layout, with well-organized menus and intuitive search functions. Information should be presented in a way that's easy to understand, avoiding overly technical language.  Think of it like explaining complex topics to a family member – clear, concise, and user-friendly. By prioritizing user experience, we can ensure that everyone has equal access to the valuable health information this website offers.</p>
            <p class = 'H1'>Services provided:</p>
            <p class = 'body'>
            1. A forum for discussions <br><br>
            2. Article from doctors to provide information <br><br>
            3. A newsletter to get daily updates on healthcare related news <br><br>
            4. Online doctor appointment making <br><br>
            </p>
            <p class = 'H1'>The creators of Help+</p>
            <p class = 'body'>1. Nicolas Yeh: b2300917 <br><br>2. Woo Hock Yimm: B2300498</p>
          </section>
        </section>

        <footer>
            <div class="footer-container">
              <nav class="footer-left">
                <ul>
                  <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
                </ul>
              </nav>
              <div class="footer-right">
                <p>© 2024 Help+</p>
                <a href="about-page.php">Credits</a>
              </div>
            </div>
          </footer>
          
          
    </body> 
</html>