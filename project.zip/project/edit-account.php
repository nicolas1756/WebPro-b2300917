<?php

session_start();
include 'connect-database.php';

// Get the account from the database
session_start();
$stmt = $pdo->prepare('SELECT * FROM accounts WHERE id = ?');
$stmt->execute([ $_SESSION['google_id']]);
$account = $stmt->fetch(PDO::FETCH_ASSOC);
// Retrieve session variables
$user_loggedin = $_SESSION['google_loggedin'];

$user_id = $account['id']; //get user id
$user_email = $_POST["Email"];
$user_name = $_POST["Name"];


$sql = "UPDATE accounts SET email = ?, name = ? WHERE id = ?";
$statement = $pdo->prepare($sql);
$statement->execute([$user_email, $user_name, $user_id]);

    session_start();
    $_SESSION["status"] = "<script>alert('Profile successfully edited.');</script>";
    header("Location: profile.php");
    exit;




?>