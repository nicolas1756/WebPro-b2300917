<?php
// Initialize the session - is required to check the login state.
session_start();

if (isset($_SESSION['status'])) { //send error message
    echo $_SESSION['status'];
    unset($_SESSION['status']);
  }

if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}

else{
  include 'connect-database.php';
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
  $user_id = -1;
}

?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>View Forum</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="colour.css">
        <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-7YY8RYJRBZ"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-7YY8RYJRBZ');
        </script>
    </head>

    <body>
        <header class="Header">
            <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
        </header>
    
        <body>
            <section class="menu">
                <div class="menu-container">  
                    
                    <nav class="navbar">
                        <ul>
                          <li><a href="Home.php">Home</a></li>
                          <li><a href="Health-information.php">Health information</a></li>
                          <li class="highlighted-menu"><a href="Forum.php">Forum</a></li>
                          <li><a href="Newsletter.php">Newsletter</a></li>
                          <li><a href="about-page.php">About us</a></li>
                        </ul>
                    </nav>
                    
                    <nav class="Profile" href="About us.html">
                        <a href="profile.php" class="sign-in" ><?=$user_name?></a>
                        <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                    </nav>
    
                </div>

                <div class="menu-container-mobile"> 
                  <div class = "pop-out-menu">
                      <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                  </div>
                  
                  <div>
                      <nav class="Profile-mobile" href="profile.php">
                      <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                      </nav>
                  </div>
              </div>

              <div id ="fix-sidebar">
                <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li class="highlighted-menu"><a href="Forum.html">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
        </section>



        <section class="margin">
            <a href="Forum.php"><button class = "Back_view_article">Back</button></a>
            <section class = "View_Forum">
                <?php 
                    $post_id = $_POST['post_id']; /*get article to load*/

                    $stmt = $pdo->prepare('SELECT * FROM posts WHERE post_id = ?');
                    $stmt->execute([$post_id]);
                    $post = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (empty($post)) { /*if article not found*/
                        session_start();
                        $_SESSION["status"] = "<script>alert('post was not found. Please try again.');</script>";
                        header("Location: Forum.php");
                        exit;
                    }

                    else {
                        $stmt = $pdo->prepare('UPDATE post_views SET trending_counter = trending_counter + 1 WHERE post_id = ?;');
                        $stmt->execute([$post_id]); /*increase view count*/

                        $stmt = $pdo->prepare('UPDATE post_views SET View_counter = View_counter + 1 WHERE post_id = ?;');
                        $stmt->execute([$post_id]); 
                        
                        $post_id = $post['post_id']; /*get forum data*/
                        $UserId = $post['user_id'];
                        $DatePublished = $post['date_published'];
                        $DatePublished = date('h:i A m/d/y', strtotime($DatePublished));
                        $content = $post['content'];
                        
                        $stmt = $pdo->prepare('SELECT View_counter FROM post_views WHERE post_id = ?');
                        $stmt->execute([$post_id]);
                        $view_count = $stmt->fetch(PDO::FETCH_ASSOC);
                        $views = $view_count['View_counter'];
          
                        $content = (explode('!$$*$%%.$',$content));
                        $Title = $content[0];
                        $Title = explode("\n", $Title);
                        $Title = implode("<br>", $Title);

                        $Body = $content[1];
                        $Body = explode("\n", $Body);
                        $Body = implode("<br>", $Body);
                        
                        $stmt = $pdo->prepare('SELECT picture, name FROM accounts WHERE id = ?');
                        $stmt->execute([$UserId]);
                        $account_details = $stmt->fetch(PDO::FETCH_ASSOC);
          
                        $account_name = $account_details['name'];
                        $account_picture = $account_details['picture'];

                        /*check post rating*/

                        $stmt = $pdo->prepare('SELECT vote FROM post_ratings WHERE post_id = ?');
                        $stmt->execute([$post_id]);
                        $votes = $stmt->fetchall(PDO::FETCH_ASSOC);
                        $vote_counter = 0;
                        foreach($votes as $vote){
                            $vote_counter = $vote_counter + $vote['vote'];
                        }

                        /*check if rated*/
                        $stmt = $pdo->prepare('SELECT vote FROM post_ratings WHERE post_id = ? and user_id = ?');
                        $stmt->execute([$post_id, $user_id]);
                        $rating = $stmt->fetch(PDO::FETCH_ASSOC);
                        @$rating = $rating['vote'];
                        
                        if (empty($rating)) { /*if article not found*/
                            $vote_status_up = 'Images\arrow_up_off.png';
                            $vote_status_down = 'Images\arrow_down_off.png';
                        }

                        elseif ($rating == 1){
                            $vote_status_up = 'Images\arrow_up_on.png';
                            $vote_status_down = 'Images\arrow_down_off.png';
                        }

                        else{
                            $vote_status_up = 'Images\arrow_up_off.png';
                            $vote_status_down = 'Images\arrow_down_on.png';
                        }

                        echo "
                        <section class = 'forum_view_background'>
                            <div class = 'post_picture_container'>
                                <div><img src='$account_picture' alt=''></div>
                                <div>$account_name</div>
                            </div>
                            
                            <p class = 'H3'>$Title</p>
                            <p class = 'body'>$Body</p>

                            <div class = 'post_view_container'>";
                                
                            if ($user_role == '@%^198278ADm1n!@#$*' || $UserId == $user_id) {
                                echo"<form action='Delete_post.php' method = 'post' id = '$post_id'>
                                        <input type='text' name='post_id' value = '$post_id' style = 'display:none'>
                                        <input type='submit' onclick='clicked(event)' id = '$post_id-button' style = 'display:none'>
                                        <div style = 'display:flex; align-items: center'>
                                            <div><label for='$post_id-button'><img src='Images/10374191.png' alt=''></label></div>
                                            <div>Views: $views</div>
                                        </div>
                                    </form>
                                    
                                    <script>
                                        function clicked(e)
                                        {
                                            if(!confirm('This will permanently delete the post.')) {
                                                e.preventDefault();
                                                document.getelementbyid('$post_id').submit();
                                            }
                                        }
                                    </script>";
                            }
                            else{
                                echo "<div>Views: $views</div>";
                            }
                                
                                
                                
                                echo "<div>$DatePublished</div>
                            </div>
                        </section>
                        
                        <form action='vote.php' id = '$post_id-vote' method = 'post'>
                            <input type='text' name='user_id' value = '$user_id' style = 'display:none'>
                            <input type='text' name='post_id' value = '$post_id' style = 'display:none'>
                            <div class = 'vote_container'>
                                <div>
                                    <input type='radio' name='vote_option' id = 'vote_up' value = 1>
                                    <label for='vote_up'><img src='$vote_status_up' alt=''></label>
                                </div>
                                <div>$vote_counter</div>
                                <div>
                                    <input type='radio' name='vote_option' id= 'vote_down' value = -1>
                                    <label for='vote_down'><img src='$vote_status_down' alt=''></label>
                                </div>
                            </div>
                        </form>

                        <script>
                            const form = document.getElementById('$post_id-vote');
                            const vote_option = document.getElementsByName('vote_option');

                            form.addEventListener('click', (event) => {
                            // Check if any radio button is checked
                            const isChecked = [...vote_option].some(radio => radio.checked);

                            // Submit the form if a radio button is checked
                            if (isChecked) {
                                form.submit();
                            }
                            });
                        </script>
                        ";

                        /*get comments*/

                        echo "
                        <div class = 'comment_section_container'>
                            <div><p class = 'H2'>Comments</p></div>
                            
                            <div>
                                <form action='add_post_comment.php' method = 'post'>
                                    <input type='text' name='post_id' value = '$post_id' style = 'display:none'>
                                    <button type ='submit' class = 'add_comment_button'>Add comment</button>
                                </form>
                            </div>
                        </div>";
                    }

                    $stmt = $pdo->prepare('SELECT post_comments.*, accounts.role FROM post_comments INNER JOIN accounts ON post_comments.user_id = accounts.id WHERE post_id = ? ORDER BY accounts.role asc, date_published DESC');
                    $stmt->execute([$post_id]); /*sql statement that gives priority to doctors and admins but also order by time published*/
                    $comments = $stmt->fetchall(PDO::FETCH_ASSOC);

                    if (empty($comments)) {
                       echo "<div class = 'comment_container'>
                                <p>No comments yet</p>
                            </div>
                       ";
                    }

                    foreach($comments as $comment){
                        $comment_id = $comment['comment_id'];
                        $comment_user = $comment['user_id'];
                        $comment_published = $comment['date_published']; 
                        $comment_published = date('h:i A m/d/y', strtotime($comment_published));

                        $stmt = $pdo->prepare('SELECT picture, name, role FROM accounts WHERE id = ?');
                        $stmt->execute([$comment_user]);
                        $account_details = $stmt->fetch(PDO::FETCH_ASSOC);
          
                        $account_name = $account_details['name'];
                        $account_picture = $account_details['picture'];
                        $account_role = $account_details['role'];

                        if($account_role == "$$66^^D0cT0R&&77"){
                            $account_role = 'Doctor';
                        }
                        elseif($account_role == "@%^198278ADm1n!@#$*"){
                            $account_role = 'Admin';
                        }
                        else{
                            $account_role = 'Standard';
                        }

                        $comment = $comment['content'];
                        $comment = explode("\n", $comment);
                        $comment = implode("<br>", $comment);
                        echo "  
                        
                        <section class = 'comment_container' id = '$comment_id-form'>
                            <div class = 'post_picture_container'>
                                <div><img src='$account_picture' alt=''></div>
                                <div>$account_name [$account_role]</div>
                            </div>
                            
                            <p class = 'Body'>$comment</p>

                            <div class = 'post_view_container'>
                                <div class = 'delete_comment_container'>";
                                    if ($user_role == '@%^198278ADm1n!@#$*' || $comment_user == $user_id) {
                                        echo"<form action='Delete_post_comment.php' method = 'post' id = '$comment_id'>
                                                <input type='text' name='post_id' value = '$post_id' style = 'display:none'>
                                                <input type='text' name='comment_id' value = '$comment_id' style = 'display:none'>
                                                <input type='submit' onclick='clicked(event)' id = '$comment_id-button' style = 'display:none'>
                                                <label for='$comment_id-button'><img src='Images/10374191.png' alt=''></label>
                                            </form>
                                            
                                            <script>
                                                function clicked(e)
                                                {
                                                    if(!confirm('This will permanently delete the comment.')) {
                                                        e.preventDefault();
                                                        document.getelementbyid('$comment_id').submit();
                                                    }
                                                }
                                            </script>";

                                    }

                                echo "</div>
                                <div>$comment_published</div>
                            </div>
                        </section>";
                    }


                ?> 
            </section>
        </section>
    </body>

      <footer>
        <div class="footer-container">
          <nav class="footer-left">
            <ul>
              <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
            </ul>
          </nav>
          <div class="footer-right">
            <p>© 2024 Help+</p>
            <a href="about-page.php">Credits</a>
          </div>
        </div>
      </footer>
</html>

