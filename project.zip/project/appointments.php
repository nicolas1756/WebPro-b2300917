<?php
// Initialize the session - is required to check the login state.
session_start();
if (isset($_SESSION['status'])) {
  echo $_SESSION['status'];
  unset($_SESSION['status']);
}

// Check if the user is logged in, if not then redirect to login page
if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Appointments</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="colour.css"> 
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" /> 
         <!-- Google tag (gtag.js) -->
         <script async src="https://www.googletagmanager.com/gtag/js?id=G-7YY8RYJRBZ"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-7YY8RYJRBZ');
        </script>
    </head>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
    <section class="menu">
            <div class="menu-container">  
                <nav class="navbar">
                    <ul>
                        
                      <li><a href="Home.php">Home</a></li>
                      <li><a href="Health-information.php">Health information</a></li>
                      <li><a href="Forum.php">Forum</a></li>
                      <li><a href="Newsletter.php">Newsletter</a></li>
                      <li><a href="about-page.php">About us</a></li>
                    </ul>
                </nav>
                
                <nav class="Profile" href="profile.php">
                    <a href="profile.php" class="sign-in" ><strong><?=$user_name?></strong></a>
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                </nav>
            </div>
            
            <div class="menu-container-mobile"> 
                <div class = "pop-out-menu">
                    <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                </div>
                
                <div>
                    <nav class="Profile-mobile" href="profile.php">
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                    </nav>
                </div>
            </div>

            <div id ="fix-sidebar">
              <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
            
        </section>


        <section class="margin">
            <section class = "view-appointments">
              <h1>My appointments</h1>
              <?php
                
                include 'connect-database.php';
            
                $stmt = $pdo->prepare('SELECT * FROM accounts WHERE id = ?');
                $stmt->execute([ $_SESSION['google_id']]);
                $account = $stmt->fetch(PDO::FETCH_ASSOC);
                // Retrieve session variables
                $user_loggedin = $_SESSION['google_loggedin'];
                $user_id = $account['id']; //get user id
                
                $sql = "SELECT appointment_id, appointment_datetime, doctor_id FROM appointments WHERE user_id = ?";
                $statement = $pdo->prepare($sql);
                $statement->execute([$user_id]);
                $appointment_data = $statement->fetchAll(PDO::FETCH_ASSOC);
                
                if (empty($appointment_data)) {
                  echo "<section class='Existing_appointment'>";
                  echo "<ul><p>No appointments made</p></ul>";
                  echo "</section>";
                }
              
                else{
                  $counter = 1;
                  $currentDate = date('Y-m-d H:i:s');
                  foreach ($appointment_data as $appointment) {
                    $appointment_id = $appointment['appointment_id'];
                    $appointment_time = $appointment['appointment_datetime'];
                    $doctor_id = $appointment['doctor_id'];
                    
                    $sql = "SELECT user_id, Doctor_location, Doctor_specialization FROM doctors WHERE Doctor_id = ?";
                    $statement = $pdo->prepare($sql);
                    $statement->execute([$doctor_id]);
                    $doctor_data = $statement->fetch(PDO::FETCH_ASSOC);
                    $appointment_location = $doctor_data['Doctor_location'];
                    $doctor_specilisation = $doctor_data['Doctor_specialization'];
                    $user_id = $doctor_data['user_id'];

                    $stmt = $pdo->prepare('SELECT name FROM accounts WHERE id = ?');
                    $stmt->execute([$user_id]);
                    $name = $stmt->fetch(PDO::FETCH_ASSOC);
                    $doctor_name = $name['name'];
                    $doctor_name = "Dr. $doctor_name";
                    
                    if ($currentDate > $appointment_time){ //check if appointment is overdue
                      echo "<section class = 'Existing_appointment_overdue'>";
                      echo "<ul><p class='warning_overdue'><strong>Warning appointment overdue:</strong></p></ul>";   
                      echo "<ul><p><strong>Appointment $counter</strong></p></ul>";                      
                      echo "<ul><p><strong>Appointment time:</strong> $appointment_time</p></ul>
                            <ul><p><strong>Appointment location:</strong> $appointment_location</p></ul>
                            <ul><p><strong>Appointment doctor:</strong> $doctor_name</p></ul>
                            <ul><p><strong>Doctor specilisation:</strong> $doctor_specilisation</p></ul>";
                      echo "<form action='remove-appointment.php' method='post'>";  // Use single quotes for consistency
                      echo '<input type="hidden" name="appointment_id" value="' . $appointment_id . '">';
                      echo "<ul><input type='submit' value='Cancel appointment'></ul>";
                      echo "</form>";
                      echo "</section>";
                    $counter = $counter + 1;
                    }
                    else{
                      echo "<section class = 'Existing_appointment'>"; 
                        echo "<ul><p><strong>Appointment $counter</strong></p></ul>";                      
                        echo "<ul><p><strong>Appointment time:</strong> $appointment_time</p></ul>
                              <ul><p><strong>Appointment location:</strong> $appointment_location</p></ul>
                              <ul><p><strong>Appointment doctor:</strong> $doctor_name</p></ul>
                              <ul><p><strong>Doctor specilisation:</strong> $doctor_specilisation</p></ul>";
                        echo "<form action='remove-appointment.php' method='post'>";  // Use single quotes for consistency
                          echo '<input type="hidden" name="appointment_id" value="' . $appointment_id . '">';
                          echo "<ul><input type='submit' value='Cancel appointment'></ul>";
                        echo "</form>";
                      echo "</section>";
                      $counter = $counter + 1;
                    }                  
                  } 
                }

              ?>
            </section>
            <section class="new-appointments">
              <ul>
                <li>
                  <p>New appointement</p>
                </li>
                <li>
                  <form action="new-appointment.php" method="post" id="form">
                    <ul><label for="doctor_id"><strong>Select a doctor:</strong><br></label></ul>
                    <?php
                      
                      include 'connect-database.php';
                      
                      $Doctors = $pdo->prepare('SELECT Doctor_id, Doctor_specialization, user_id FROM doctors ORDER BY Doctor_specialization');
                      $Doctors->execute();
                      $doctor_data = $Doctors->fetchAll(PDO::FETCH_ASSOC);
                      // Database connection and data retrieval (same as your provided code)
                      foreach ($doctor_data as $doctor) {
                          $doctor_id = $doctor['Doctor_id'];
                          $user_id = $doctor['user_id'];
                          $doctor_specialization = $doctor['Doctor_specialization'];
                          
                          $stmt = $pdo->prepare('SELECT name FROM accounts WHERE id = ?');
                          $stmt->execute([$user_id]);
                          $name = $stmt->fetch(PDO::FETCH_ASSOC);
                          $doctor_name = $name['name'];
                          $doctor_name = "Dr. $doctor_name";

                          echo " <ul><input type='radio' name='doctor_id' value='$doctor_id' id='doctor_id' required> <label for='$doctor_id'>$doctor_name [$doctor_specialization]</label><br></ul>";
                      }
                    ?>
                    <ul><label for="date-time" id = "date-time-label"><strong>Select date and time:</strong></label></ul>
                    <ul><input type="text" name="date-time" id="date-time" placeholder="Select time" required/></ul>
                    <ul><input type="submit" value="Submit"></ul>
                    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
                    <script>
                      flatpickr("#date-time", {
                          "disable": [
                          function(date) {
                              // return true to disable
                              return (date.getDay() === 0 || date.getDay() === 6);

                          }
                          ],
                          "locale": {
                              "firstDayOfWeek": 1 // start week on Monday
                          },
                          dateFormat: "Y-m-d H:i",
                          minuteIncrement: 30,
                          minDate: new Date().fp_incr(1),
                          maxDate: new Date().fp_incr(7),
                          enableTime: true,
                          minuteIncrement: 30,
                          minTime: "09:00",
                          maxTime: "17:00"
                      });
                    </script>
                  </form>
                </li>     
              </ul>
            </section>
        </section>

        <footer>
            <div class="footer-container">
              <nav class="footer-left">
                <ul>
                  <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
                </ul>
              </nav>
              <div class="footer-right">
                <p>© 2024 Help+</p>
                <a href="about-page.php">Credits</a>
              </div>
            </div>
          </footer>
          
          
    </body> 
</html>