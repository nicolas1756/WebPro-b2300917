<?php
// Initialize the session - is required to check the login state.
session_start();

if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  include 'connect-database.php';
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>View article</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="colour.css">
        <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-7YY8RYJRBZ"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-7YY8RYJRBZ');
        </script>
    </head>

    <body>
        <header class="Header">
            <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
        </header>
    
        <body>
            <section class="menu">
                <div class="menu-container">  
                    
                    <nav class="navbar">
                        <ul>
                          <li><a href="Home.php">Home</a></li>
                          <li class="highlighted-menu"><a href="Health-information.php">Health information</a></li>
                          <li><a href="Forum.php">Forum</a></li>
                          <li><a href="Newsletter.php">Newsletter</a></li>
                          <li><a href="about-page.php">About us</a></li>
                        </ul>
                    </nav>
                    
                    <nav class="Profile" href="About us.html">
                        <a href="profile.php" class="sign-in" ><?=$user_name?></a>
                        <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                    </nav>
    
                </div>

                <div class="menu-container-mobile"> 
                  <div class = "pop-out-menu">
                      <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                  </div>
                  
                  <div>
                      <nav class="Profile-mobile" href="profile.php">
                      <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                      </nav>
                  </div>
              </div>

              <div id ="fix-sidebar">
                <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li class="highlighted-menu"><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.html">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
        </section>



        <section class="margin">
            <a href="Health-information.php"><button class = "Back_view_article">Back</button></a>
            <section class = "View_article">
                <?php 
                    $article_id = $_POST['Article_id']; /*get article to load*/

                    $stmt = $pdo->prepare('SELECT * FROM articles WHERE article_id = ?');
                    $stmt->execute([$article_id]);
                    $article = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (empty($article)) { /*if article not found*/
                        session_start();
                        $_SESSION["status"] = "<script>alert('Article was not found. Please try again.');</script>";
                        header("Location: Health-information.php");
                        exit;
                    }

                    else {
                        $stmt = $pdo->prepare('UPDATE article_views SET trending_counter = trending_counter + 1 WHERE article_id = ?;');
                        $stmt->execute([$article_id]); /*increase view count*/

                        $stmt = $pdo->prepare('UPDATE article_views SET view_counter = view_counter + 1 WHERE article_id = ?;');
                        $stmt->execute([$article_id]); 
                        
                        include 'decode_article.php';

                        $count = 0;
                        foreach ($content as $index => $Body) {

                            $stmt = $pdo->prepare('SELECT view_counter FROM article_views WHERE article_id = ?');
                            $stmt->execute([$article_id]);
                            $view_count = $stmt->fetch(PDO::FETCH_ASSOC);
                            $view_count = $view_count['view_counter'];

                            if ($count == 0){
                                echo "<p class = '$Format[$index]'>$Body</p>"; /*format top of article*/
                                echo "<p class ='body'>$user_name -- $date_published</p>";
                                echo "<p class ='body'>Views: $view_count</p>";
                                $count += 1;
                                continue;
                            }
                            echo "<p class = '$Format[$index]'>$Body</p>";
                        }
                    }

                    
                ?> 
            </section>
        </section>
    </body>

      <footer>
        <div class="footer-container">
          <nav class="footer-left">
            <ul>
              <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
            </ul>
          </nav>
          <div class="footer-right">
            <p>© 2024 Help+</p>
            <a href="about-page.php">Credits</a>
          </div>
        </div>
      </footer>
</html>

