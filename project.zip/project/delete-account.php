<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    session_start();
    include 'connect-database.php';
    
    $id = $_POST["account_id"];

    $sql = "DELETE FROM doctors WHERE user_id = ?";
    $statement = $pdo->prepare($sql);
    $statement->execute([$id]);

    $sql = "DELETE FROM appointments WHERE user_id = ?";
    $statement = $pdo->prepare($sql);
    $statement->execute([$id]);

    $stmt = $pdo->prepare('SELECT article_id FROM articles WHERE user_id = ?');
    $stmt->execute([$id]);
    $articles = $stmt->fetchall(PDO::FETCH_ASSOC);

    foreach($articles as $articleid){
        $articleid = $articleid['article_id'];
        $sql = "DELETE FROM article_views WHERE article_id = ?";
        $statement = $pdo->prepare($sql);
        $statement->execute([$articleid]);

        $sql = "DELETE FROM articles WHERE article_id = ?";
        $statement = $pdo->prepare($sql);
        $statement->execute([$articleid]);

        $stmt = $pdo->prepare('SELECT post_id FROM posts WHERE user_id = ?');
        $stmt->execute([$id]);
        $posts = $stmt->fetchall(PDO::FETCH_ASSOC);
    }

    $stmt = $pdo->prepare('SELECT post_id FROM posts WHERE user_id = ?');
    $stmt->execute([$id]);
    $posts = $stmt->fetchall(PDO::FETCH_ASSOC);

    foreach($posts as $postid){ 

        $postid = $postid['post_id'];
        $sql = "DELETE FROM post_views WHERE post_id = ?";
        $statement = $pdo->prepare($sql);
        $statement->execute([$postid]);

        $sql = "DELETE FROM post_comments WHERE post_id = ?";
        $statement = $pdo->prepare($sql);
        $statement->execute([$postid]);

        $sql = "DELETE FROM posts WHERE post_id = ?";
        $statement = $pdo->prepare($sql);
        $statement->execute([$postid]);
    }

    $sql = "DELETE FROM accounts WHERE id = ?";
    $statement = $pdo->prepare($sql);
    $statement->execute([$id]);

    session_start();
    $_SESSION["status"] = "<script>alert('account successfully removed.');</script>";
    header("Location: admin-panel.php");
    exit;  

}
?>