<?php 
  session_start();
  include 'connect-database.php';
  include 'get-profile-data.php';


  $UserId = $user_id;
  $DatePublished = date("Y-m-d H:i:s");
  
  $Names = $_POST['transferName'];
  $Values = $_POST['transferValue'];

  $EncodededArticle = ("$Names!$$*$%%.$$Values"); /*formats the 2 variables in to a single string with the first part storing the format and second storing the data*/

  $stmt = $pdo->prepare('INSERT INTO articles (user_id, date_published, content) VALUES (?, ?, ?)');
  $stmt->execute([$UserId, $DatePublished, $EncodededArticle]);

  session_start();
  $_SESSION["status"] = "<script>alert('Article successfully added.');</script>";
  header("Location: Health-information.php");
  exit;
  



  
 

    
     
?>