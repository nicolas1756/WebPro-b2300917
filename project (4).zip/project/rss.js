function getRssFeed(feedUrl) {
    fetch(feedUrl)
      .then(response => response.text())
      .then(str => new DOMParser().parseFromString(str, "text/xml"))
      .then(data => {
        const items = data.querySelectorAll("item");
        let html = "";
        items.forEach(item => {
          const title = item.querySelector("title").textContent;
          const link = item.querySelector("link").textContent;
          html += `
            <article>
              <h3><a href="${link}" target="_blank">${title}</a></h3>
            </article>
          `;
        });
        document.getElementById("feed-container").insertAdjacentHTML("beforeend", html);
      });
  }
  
  const feedUrl = "https://rss.beehiiv.com/feeds/Ubg9ubu9ka.xml"; // Replace with the actual RSS feed URL
  getRssFeed(feedUrl);
  