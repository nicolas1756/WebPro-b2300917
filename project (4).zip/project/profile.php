<?php
// Initialize the session - is required to check the login state.
session_start();
if (isset($_SESSION['status'])) {
    echo $_SESSION['status'];
    unset($_SESSION['status']);
}

// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION['google_loggedin'])) {
    header('Location: sign-in-google.html');
    exit;
}
else{
    include 'get-profile-data.php';
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,minimum-scale=1">
		<title>Profile</title>
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
		<link href="colour.css" rel="stylesheet" type="text/css">
         <!-- Google tag (gtag.js) -->
         <script async src="https://www.googletagmanager.com/gtag/js?id=G-7YY8RYJRBZ"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-7YY8RYJRBZ');
        </script>
	</head>
	<body>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
        <section class="menu">
            <div class="menu-container">  
                <nav class="navbar">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </nav>
                
                <nav class="Profile" href="profile.php">
                    <a href="profile.php" class="sign-in"><strong><?=$user_name?></strong></a>
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                </nav>
            </div>
            
            <div class="menu-container-mobile"> 
                <div class = "pop-out-menu">
                    <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                </div>
                
                <div>
                    <nav class="Profile-mobile" href="profile.php">
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                    </nav>
                </div>
            </div>

            <div id ="fix-sidebar">
              <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
            
        </section>



		<section class="margin">
            
        <section class="profile-header">
            <div class="profile-header-container">
                <ul>
                    <li class="profile-header-pic">
                        <div class="profile-image-container">
                            <img src="<?=$user_picture?>" alt="">
                            <p><?=$user_name?></p>
                        </div>
                    </li>
                    
                    <a href="appointments.php">
                        <li class="profile-header-button">
                            <p>Your appointments</p>
                        </li>
                    </a>
                </ul>
            </div>
        </section>


              <section class="Profile-info-section">
                <form id = "profile-data" action="edit-account.php" method="POST">
                    <ul class="Profile-data">
                        <li class = "button-edit">
                            <button id="edit-button">Edit</button>
                            <button id="cancel-button" onclick="document.getElementById('profile-data').reset()">Cancel</button>
                            <button type="submit" id="save-button">Save</button>
                        </li>
                        <li>
                            <label for="Name">Name: </label>
                            <input type="text" id="edit" name="Name" value="<?=$user_name?>" readonly>
                        </li>

                        <li>
                            <label for="Dateofbirth">Date of birth: </label>
                            <input type="text" name="Dateofbirth" value="<?=$user_birthdate?>" readonly>
                        </li>

                        <li>
                            <label for="Sex">Sex: </label>
                            <input type="text" name="Sex" value="<?=$user_sex?>" readonly>
                        </li>

                        <li>
                            <label for="Email">Email: </label>
                            <input type="text" name="Email" id="edit1" value="<?=$user_email?>"readonly>
                        </li>
                        <script>
                            const textBox = document.getElementById('edit');
                            const textBox1 = document.getElementById('edit1');
                            const editButton = document.getElementById('edit-button');
                            const cancelButton = document.getElementById('cancel-button');
                            const saveButton = document.getElementById('save-button');
                            const defaultValue = textBox.value;
                            const defaultValue1 = textBox1.value;
                            saveButton.style.visibility="hidden";
                            cancelButton.style.visibility="hidden";
                            

                            editButton.addEventListener('click', () => {
                                event.preventDefault();
                                textBox.removeAttribute("readonly"); // Make editable on click
                                textBox1.removeAttribute("readonly"); // Make editable on click
                                textBox.style.backgroundColor = 'lightgrey';
                                textBox1.style.backgroundColor = 'lightgrey';
                                saveButton.style.visibility="visible"; // Enable save button
                                cancelButton.style.visibility="visible";
                            });

                            cancelButton.addEventListener('click', () => {
                                event.preventDefault();
                                textBox.readOnly = true; // Make editable on click
                                textBox1.readOnly = true; // Make editable on click
                                textBox.style.backgroundColor = 'transparent';
                                textBox1.style.backgroundColor = 'transparent';
                                saveButton.style.visibility="hidden";
                                cancelButton.style.visibility="hidden";
                            });

                            textBox1.onchange = function() {
                            if (this.value !== defaultValue1) {
                                alert("Warning: Ensure email address is valid or account may be permanently lost.");
                            }
                            };
                        </script>

                        <li class="logout-btn">
                            <a href="logout.php">Logout</a>
                        </li>
                        <script>
                            function makeEditable() {
                                // Get the input element
                                var input = document.getElementById("input");
                                input.removeAttribute("readonly");
                            }
                        </script>
                    </ul>
                </form>
              </section>
        </section>

        <footer>
            <div class="footer-container">
              <nav class="footer-left">
                <ul>
                  <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
                </ul>
              </nav>
              <div class="footer-right">
                <p>© 2024 Help+</p>
                <?php 
                    if ($user_role == "@%^198278ADm1n!@#$*"){
                        echo "<a href='admin-panel.php'>Admin Menu</a><br>";
                    }
                ?>
                <a href="about-page.php">Credits</a>
              </div>
            </div>
        </footer>
	</body>
</html>