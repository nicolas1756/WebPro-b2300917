<?php
include 'connect-database.php';

$appointment_id = $_POST["appointment_id"];

$sql = "DELETE FROM appointments WHERE appointment_id = ?";
$statement = $pdo->prepare($sql);
$statement->execute([$appointment_id]);


session_start();
$_SESSION["status"] = "<script>alert('Appointment successfully deleted.');</script>";
header("Location: appointments.php");
exit;

?>