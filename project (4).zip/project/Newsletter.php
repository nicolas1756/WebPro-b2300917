<?php
// Initialize the session - is required to check the login state.
session_start();
// Check if the user is logged in, if not then redirect to login page
if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Newsletter</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="colour.css">
         <!-- Google tag (gtag.js) -->
         <script async src="https://www.googletagmanager.com/gtag/js?id=G-7YY8RYJRBZ"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-7YY8RYJRBZ');
        </script>
    </head>

    <body>
        <header class="Header">
            <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
        </header>
    
        <body>
            <section class="menu">
                <div class="menu-container">  
                    
                    <nav class="navbar">
                        <ul>
                          <li><a href="Home.php">Home</a></li>
                          <li><a href="Health-information.php">Health information</a></li>
                          <li><a href="Forum.php">Forum</a></li>
                          <li class="highlighted-menu"><a href="Newsletter.php">Newsletter</a></li>
                          <li><a href="about-page.php">About us</a></li>
                        </ul>
                    </nav>
                    
                    <nav class="Profile" href="About us.html">
                        <a href="profile.php" class="sign-in" ><?=$user_name?></a>
                        <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                    </nav>
    
                </div>

                <div class="menu-container-mobile"> 
                  <div class = "pop-out-menu">
                      <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                  </div>
                  
                  <div>
                      <nav class="Profile-mobile" href="profile.php">
                      <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                      </nav>
                  </div>
              </div>

              <div id ="fix-sidebar">
                <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li class="highlighted-menu"><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
            </section>



            <section class="margin">
            
                <section class="Newsletter_logo">

                    <div class="Newsletter-container">
                      <img src="Images\Newsletter Logo.png" alt="">
                    </div>

                    <section class="Newsletter_input">
                        <div class="Newsletter-left">
                            <iframe src="https://embeds.beehiiv.com/15114c75-ccbf-4302-b3b7-d80d6ede12ea?slim=true" data-test-id="beehiiv-embed" height="52" width="500" frameborder="0" scrolling="no" style="margin: 1; border-radius: 0px !important; background-color: transparent;"></iframe>
                        </div>
                    </section>
                </section>
                
                
                <section class="view-news">
                  <h1>Posts</h1>
                  <?php
                    $feed_url = "https://rss.beehiiv.com/feeds/Ubg9ubu9ka.xml";

                    $xml = simplexml_load_file($feed_url);

                    if (!$xml) {
                      echo "Error: Unable to load RSS feed.";
                      exit;
                    }

                    echo "<div class='news-container'>";
                    
                    foreach ($xml->channel->item as $item) {
                      $datepublished = $item->pubDate;
                      $formated_date = date(' D Y-m-d', strtotime($datepublished));
                      $title = $item->title;
                      $link = $item->link;


                    echo "<div class = 'trending-post'>";
                    echo "<div class = 'post-seperator'><div><h2>$title</h2></div>";
                    echo "<div><div class='trending_container'>";
                      echo "<div>$formated_date</div>";
                      
                      echo "<div>";
                        echo "<form action='$link' method=''>";
                            echo "<input type='text' name='Article_id' value='' style = 'display: none'>";
                            echo "<button type='submit' class = 'Read_article_button'>Read more</button>";
                        echo "</form>";
                      echo "</div>";
                  echo "</form>";
                    echo "</div></div></div>";
                echo "</div>";
                    }
                  ?>

                </section>
              </section>
    </body>

      <footer>
        <div class="footer-container">
          <nav class="footer-left">
            <ul>
              <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
            </ul>
          </nav>
          <div class="footer-right">
            <p>© 2024 Help+</p>
            <?php 
                if ($user_role == "@%^198278ADm1n!@#$*"){
                    echo "<a href='https://app.beehiiv.com/' target='_blank' rel='noopener noreferrer'>Beehiv Dashboard</a><br>";
                }
            ?>
            <a href="about-page.php" >Credits</a>
          </div>
        </div>
      </footer>
</html>

