function textAreaSettings(){
    /*resize textarea*/
    const tx = document.getElementsByTagName("textarea");
    for (let i = 0; i < tx.length; i++) {
        tx[i].setAttribute("style", "height:" + (tx[i].scrollHeight) + "px;overflow-y:hidden;");
        tx[i].addEventListener("input", OnInput, false);
    }

    function OnInput() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + "px";
    }

    
    /*allow indentation*/
    const textareas = document.querySelectorAll('textarea');

    textareas.forEach(function(textarea) {
    textarea.addEventListener('keydown', function(e) {
        if (e.key === 'Tab' && e.target === this) { // Check for Tab key and target element
        e.preventDefault();
        var start = this.selectionStart;
        var end = this.selectionEnd;

        this.value = this.value.substring(0, start) +
                    "\t" + this.value.substring(end);

        this.selectionStart = this.selectionEnd = start + 1;
        }
    });

    
    });
}