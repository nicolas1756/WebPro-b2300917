<?php
include 'connect-database.php';

// Get the account from the database
$stmt = $pdo->prepare('SELECT * FROM accounts WHERE id = ?');
$stmt->execute([ $_SESSION['google_id']]);
$account = $stmt->fetch(PDO::FETCH_ASSOC);
// Retrieve session variables
$user_loggedin = $_SESSION['google_loggedin'];
$user_id = $account['id'];
$user_email = $account['email'];
$user_sex = $account['sex'];
$user_name = $account['name'];
$user_picture = $account['picture'];
$user_birthdate = $account['birthdate'];
$user_role = $account['role'];

?>