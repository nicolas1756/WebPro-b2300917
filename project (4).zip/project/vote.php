<?php 

include 'connect-database.php';

$vote = $_POST['vote_option'];
$user_id = $_POST['user_id'];
$post_id = $_POST['post_id'];

if ($user_id == -1){
  header("Location: Profile.php");
}

$stmt = $pdo->prepare('SELECT vote FROM post_ratings WHERE post_id = ? and user_id = ?');
$stmt->execute([$post_id, $user_id]);
$rating = $stmt->fetch(PDO::FETCH_ASSOC);
@$rating = $rating['vote'];

if (empty($rating)) {
    $stmt = $pdo->prepare('INSERT INTO post_ratings (user_id, post_id, vote) VALUES (?, ?, ?)');
    $stmt->execute([$user_id, $post_id, $vote]); 
}

elseif($rating == $vote){
    $sql = "DELETE FROM post_ratings WHERE user_id = ? and post_id = ?";
    $statement = $pdo->prepare($sql);
    $statement->execute([$user_id, $post_id]);
}

elseif($rating != $vote){ 
    $sql = "UPDATE post_ratings SET vote = ? WHERE user_id = ? and post_id = ?";
    $statement = $pdo->prepare($sql);
    $statement->execute([$vote, $user_id, $post_id]);
}


  echo"
  <form action='View_forum_post.php' id = 'form' method = 'post'>
      <input type='text' name='post_id' value = '$post_id' style = 'display:none'>
  </form>
  
  <script>
    document.getElementById('form').submit();
  </script>
  ";
  





?>