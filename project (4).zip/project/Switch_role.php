<?php
    session_start();
    include 'get-profile-data.php';

    $Role = $_POST["role_to_switch"];

    $sql = "UPDATE accounts SET role = ? WHERE id = ?";
    $statement = $pdo->prepare($sql);
    $statement->execute([$Role, $user_id]);

    echo "<script>javascript:history.go(-1)</script>";
?>