<?php
//reset trending
$stmt = $pdo->prepare('SELECT week_reset FROM Last_trending_reset'); 
$stmt->execute([]);
$last_reset = $stmt->fetch(PDO::FETCH_ASSOC);
$last_reset = $last_reset['week_reset'];

$dateFromSevenDaysAgo = date('Y-m-d', strtotime('-7 day'));


if ($last_reset <= $dateFromSevenDaysAgo) {
  $stmt = $pdo->prepare('UPDATE article_views SET trending_counter = 0');
  $stmt->execute([]);

  $stmt = $pdo->prepare('UPDATE post_views SET trending_counter = 0');
  $stmt->execute([]);
  
  $stmt = $pdo->prepare('UPDATE Last_trending_reset SET week_reset = ?');
  $stmt->execute([date('Y-m-d')]);
}
?>