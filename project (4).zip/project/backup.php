<?php

session_start();

if (isset($_SESSION['status'])) { //send error message
  echo $_SESSION['status'];
  unset($_SESSION['status']);
}

if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Help+</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="colour_mandatory.css">
    </head>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
      <section class="menu">
        <div class="menu-container">  
            <nav class="navbar">
                <ul>
                    <strong>
                        <li class="highlighted-menu"><a href="Home.php">Home</a></li>
                        <li><a href="Health information.html">Health information</a></li>
                        <li><a href="Forum.html">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </strong>
                </ul>
            </nav>
            
            <nav class="Profile" href="profile.php">
                <a href="profile.php" class="sign-in" ><strong><?=$user_name?></strong></a>
                <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
            </nav>
        </div>
          
        <div class="menu-container-mobile"> 
          <div class = "pop-out-menu">
            <img id = "menu-icon-mobile" onclick="javascript:sidebar()" src="Images\burger-menu.png" />
          </div>
          
          <div>
            <nav class="Profile-mobile" href="profile.php">
              <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
            </nav>
          </div>
        </div>
      </section>
    
      <div class = "body-container">

        <div class="secondary-menu-container">
          <nav class="menu-options">
            <ul>
              <li><a href="home.html"><img src="Images\Health information.png" class="Header_logo"></a></li>
              <li><a href="Forum.html"><img src="Images\Forum.png" class="Header_logo"></a></li>
              <li><a href="Newsletter.php"><img src="Images\Newsletter.png" class="Header_logo"></a></li>
            </ul>
          </nav>
        </div>


          <div id = "sidebar-menu">
            <ul>
              <li class="highlighted-menu"><a href="Home.php">Home</a></li>
              <li><a href="Health information.html">Health information</a></li>
              <li><a href="Forum.html">Forum</a></li>
              <li><a href="Newsletter.php">Newsletter</a></li>
              <li><a href="about-page.php">About us</a></li>
            </ul>
          </div>

          <script>
            const img = document.getElementById('menu-icon-mobile');
            const menu = document.getElementById('sidebar-menu');
            function sidebar() {
              menu.style.display = menu.style.display === 'none' ? 'flex' : 'none';
            }
          </script>

      </div>    
    </body> 

    <footer>
        <div class="footer-container">
            <nav class="footer-left">
            <ul>
                <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
            </ul>
            </nav>
            <div class="footer-right">
            <p>© 2024 Help+</p>
            <a href="about-page.php">Credits</a>
            </div>
        </div>
    </footer>
    
</html>