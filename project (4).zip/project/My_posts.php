<?php
// Initialize the session - is required to check the login state.
session_start();

if (isset($_SESSION['status'])) { //send error message
  echo $_SESSION['status'];
  unset($_SESSION['status']);
}

if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}

if ($user_role == 'unregistered'){ //value for if an account is an admin
    header("Location: Profile.php");
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,minimum-scale=1">
		<title>Profile</title>
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
		<link href="colour.css" rel="stylesheet" type="text/css">
	</head>
	<body>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
        <section class="menu">
            <div class="menu-container">  
                <nav class="navbar">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li class="highlighted-menu"><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </nav>
                
                <nav class="Profile" href="profile.php">
                    <a href="profile.php" class="sign-in" ><?=$user_name?></a>
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                </nav>
            </div>
            
            <div class="menu-container-mobile"> 
                <div class = "pop-out-menu">
                    <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                </div>
                
                <div>
                    <nav class="Profile-mobile" href="profile.php">
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                    </nav>
                </div>
            </div>

            <div id ="fix-sidebar">
              <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li class="highlighted-menu"><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
            
        </section>

		<section class="margin">
            <a href="Forum.php" class='My_articles_button'>Back</a>

            <section class = 'My_posts_Section'>

                <h1>My posts</h1>
                <?php
                
                $stmt = $pdo->prepare('SELECT * FROM posts WHERE user_id = ?');
                $stmt->execute([$user_id]);
                $posts = $stmt->fetchall(PDO::FETCH_ASSOC);

                if (empty($posts)) {
                echo "<div class = 'My_articles_container'>
                        <div>
                            <p>No articles written yet</p>
                        </div>
                    </div>";
                }

                else{
                    foreach($posts as $post){
                        $post_id = $post['post_id'];
                        $UserId = $post['user_id'];
                        $DatePublished = $post['date_published'];
                        $DatePublished = date('h:i A m/d/y', strtotime($DatePublished));
                        $content = $post['content'];
                        
                        $stmt = $pdo->prepare('SELECT View_counter FROM post_views WHERE post_id = ?');
                        $stmt->execute([$post_id]);
                        $view_count = $stmt->fetch(PDO::FETCH_ASSOC);
                        $views = $view_count['View_counter'];
            
                        $content = (explode('!$$*$%%.$',$content));
                        $Title = $content[0];
                        $Body = $content[1];
                        
                        $Title = strlen($Title) > 80 ? substr($Title,0,80)."..." : $Title;
                        $Body = strlen($Body) > 120 ? substr($Body,0,120)."..." : $Body;
                        
                        $stmt = $pdo->prepare('SELECT picture, name FROM accounts WHERE id = ?');
                        $stmt->execute([$UserId]);
                        $account_details = $stmt->fetch(PDO::FETCH_ASSOC);
            
                        $account_name = $account_details['name'];
                        $account_picture = $account_details['picture'];
            
                        
                        echo "<div><form action='View_forum_post.php' method = 'post' class= 'forum_post_container'> 
                        <input type='text' name='post_id' value = '$post_id' style = 'display:none'>
                        <button type = 'submit' class = 'forum_post_background'>
                            <div class = 'post_picture_container'>
                                <div><img src='$account_picture' alt=''></div>
                                <div>$account_name</div>
                            </div>
                            
                            <p class = 'H3'>$Title</p>
                            <p class = 'Body'>$Body</p>

                            <div class = 'post_view_container'>
                                <div>Views: $views</div>
                                <div>$DatePublished</div>
                            </div>
                        </button>
                        </form></div>
            ";
                    }  
                }
                ?>
            </section>

            <section class= 'My_comments_Section'>
                <h1>My comments</h1>
                <?php 
                    $stmt = $pdo->prepare('SELECT * FROM post_comments WHERE user_id = ?');
                    $stmt->execute([$user_id]);
                    $comments = $stmt->fetchall(PDO::FETCH_ASSOC);

                    foreach($comments as $comment){
                        $comment_id = $comment['comment_id'];
                        $post_id = $comment['post_id'];
                        $comment_user = $comment['user_id'];
                        $comment_published = $comment['date_published']; 
                        $comment_published = date('h:i A m/d/y', strtotime($comment_published));

                        $stmt = $pdo->prepare('SELECT * FROM posts WHERE post_id = ?');
                        $stmt->execute([$post_id]);
                        $post = $stmt->fetch(PDO::FETCH_ASSOC);
                        $UserId = $post['user_id'];
                        $content = $post['content'];
                        $content = (explode('!$$*$%%.$',$content));
                        $Title = $content[0];
                        $Title = strlen($Title) > 80 ? substr($Title,0,80)."..." : $Title;

                        $stmt = $pdo->prepare('SELECT picture, name, role FROM accounts WHERE id = ?');
                        $stmt->execute([$comment_user]);
                        $account_details = $stmt->fetch(PDO::FETCH_ASSOC);
          
                        $account_name = $account_details['name'];
                        $account_picture = $account_details['picture'];
                        $account_role = $account_details['role'];

                        if($account_role == "$$66^^D0cT0R&&77"){
                            $account_role = 'Doctor';
                        }
                        elseif($account_role == "@%^198278ADm1n!@#$*"){
                            $account_role = 'Admin';
                        }
                        else{
                            $account_role = 'Standard';
                        }

                        $comment = $comment['content'];
                        $comment = explode("\n", $comment);
                        $comment = implode("<br>", $comment);
                        $comment = strlen($comment) > 120 ? substr($comment,0,120)."..." : $comment;


                        echo "  
                        <form action='View_forum_post.php#$comment_id-form' method = 'post' class= 'forum_post_container'> 
                            <input type='text' name='post_id' value = '$post_id' style = 'display:none'>
                            <button type = 'submit' class = 'My_comment_container'>
                                <div class = 'post_picture_container'>
                                    <div><img src='$account_picture' alt=''></div>
                                    <div>$account_name [$account_role]</div>
                                </div>
                                
                                <p class = 'H3'>Commented on: $Title</p>
                                <p class = 'Body'>$comment</p>

                                <div class = 'post_view_container'>
                                    <div class = 'delete_comment_container'>";
                                    echo "</div>
                                    <div>$comment_published</div>
                                </div>
                            </button>
                        </form>

                        <script>

                            
                            
                            ";
                        
                    }
                ?>
            </section>
            
        </section>

        <footer>
            <div class="footer-container">
              <nav class="footer-left">
                <ul>
                  <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
                </ul>
              </nav>
              <div class="footer-right">
                <p>© 2024 Help+</p>
                <a href="about-page.php">Credits</a>
              </div>
            </div>
        </footer>
	</body>
</html>