<?php 
  session_start();
  include 'connect-database.php';
  include 'get-profile-data.php';


  $UserId = $user_id;
  $DatePublished = date("Y-m-d H:i:s");
  
  $Names = $_POST['transferName'];
  $Values = $_POST['transferValue'];
  $articleid = $_POST['transferID'];

  $EncodededArticle = ("$Names!$$*$%%.$$Values"); /*formats the 2 variables in to a single string with the first part storing the format and second storing the data*/

  $sql = "UPDATE articles SET content = ? where article_id = ?";
  $statement = $pdo->prepare($sql);
  $statement->execute([$EncodededArticle, $articleid]);

  if ($rowsAffected === 0) {
    session_start();
    $_SESSION["status"] = "<script>alert('Article was not edited. Please try again.');</script>";
    header("Location: Health-information.php");
    exit;
  } else {
      session_start();
      $_SESSION["status"] = "<script>alert('Article successfully edited.');</script>";
      header("Location: Health-information.php");
      exit;
  }



  
 

    
     
?>