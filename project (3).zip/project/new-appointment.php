<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    
    include 'connect-database.php';
    
    session_start();
    $stmt = $pdo->prepare('SELECT * FROM accounts WHERE id = ?');
    $stmt->execute([ $_SESSION['google_id']]);
    $account = $stmt->fetch(PDO::FETCH_ASSOC);
    // Retrieve session variables
    $user_loggedin = $_SESSION['google_loggedin'];
    $user_id = $account['id']; //get user id

    $date_time_chosen = $_POST['date-time'];
    if ($date_time_chosen === ""){
        session_start();
        $_SESSION["status"] = "<script>alert('Error: Time of appointment was not chosen. Please try again');</script>";
        header("Location: appointments.php");
        exit;
    }
    
    $Doctor_id = $_POST['doctor_id'];
    $sql = "SELECT appointment_datetime FROM appointments WHERE doctor_id = ?";
    $statement = $pdo->prepare($sql);
    $statement->execute([$Doctor_id]);
    $appointment_data = $statement->fetchAll(PDO::FETCH_ASSOC);

    $isAvailable = true;
    foreach ($appointment_data as $appointment) {
        $existingDateTime = strtotime($appointment['appointment_datetime']);
        $selectedDateTime = strtotime($date_time_chosen);
        if ($existingDateTime == $selectedDateTime) {
            $isAvailable = false;
            break;
        }
        }

        if ($isAvailable) { //if appointment time avalable
            $stmt = $pdo->prepare('INSERT INTO appointments (user_id, doctor_id, appointment_datetime) VALUES (?, ?, ?)');
            $stmt->execute([$user_id, $Doctor_id, $date_time_chosen]);
            session_start();
            $_SESSION["status"] = "<script>alert('Appointment added.');</script>";
            header("Location: appointments.php");
            exit;
        } 
        
        else { //if apppointment time unavalable
            session_start();
            $_SESSION["status"] = "<script>alert('Sorry, this doctor is already booked at that time. Please choose another time.');</script>";
            header("Location: appointments.php");
            exit;
        }
}



?>
