<?php
// Initialize the session - is required to check the login state.
session_start();

if (isset($_SESSION['Edit_article'])) { /*clear loaded article*/
    unset($_SESSION['Edit_article']);
    unset($_SESSION['Edit_article_ID']);
  }

if (isset($_SESSION['status'])) { //send error message
  echo $_SESSION['status'];
  unset($_SESSION['status']);
}

if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}

if ($user_role != "@%^198278ADm1n!@#$*" and $user_role != "$$66^^D0cT0R&&77"){ //value for if an account is an admin
    session_start();
    $_SESSION["status"] = "<script>alert('Account does not meet required security clearance.');</script>";
    header("Location: Health-information.php");
    exit;
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,minimum-scale=1">
		<title>Profile</title>
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
		<link href="colour.css" rel="stylesheet" type="text/css">
	</head>
	<body>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
        <section class="menu">
            <div class="menu-container">  
                <nav class="navbar">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li class="highlighted-menu"><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </nav>
                
                <nav class="Profile" href="profile.php">
                    <a href="profile.php" class="sign-in" ><?=$user_name?></a>
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                </nav>
            </div>
            
            <div class="menu-container-mobile"> 
                <div class = "pop-out-menu">
                    <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                </div>
                
                <div>
                    <nav class="Profile-mobile" href="profile.php">
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                    </nav>
                </div>
            </div>

            <div id ="fix-sidebar">
              <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li class="highlighted-menu"><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
            
        </section>

		<section class="margin">
            <a href="Write_article.php" class='My_articles_button'>Start Writing</a>

            <section class = 'My_articles_Section'>

                <h1>My articles</h1>
                    
                <?php
                
                $stmt = $pdo->prepare('SELECT * FROM articles WHERE user_id = ?');
                $stmt->execute([$user_id]);
                $articles = $stmt->fetchall(PDO::FETCH_ASSOC);

                if (empty($articles)) {
                echo "<div class = 'My_articles_container'>
                        <div>
                            <p>No articles written yet</p>
                        </div>
                    </div>";
                }

                else{
                    foreach ($articles as $article){
                        include 'decode_article.php';
        
                        $article_id = $article['article_id'];
                        $title = $content[0];
                        $title = str_replace("<br>", "", $title);

                        echo "<div class = 'My_articles_container'>
                            <div>
                                <p>$title</p>
                            </div>
                            
                            <div class = 'My_Article_option'>
                                <form action='View-article.php' method='post'>
                                    <input name = 'Article_id' type='text' style= 'display: none' value = '$article_id'>
                                    <div><button type='submit' class = 'Read_article_button'>View</button></div>
                                </form>

                                <form action='Edit-article.php' method='post'>
                                    <input name = 'Article_id' type='text' style= 'display: none' value = '$article_id'>
                                    <div><button type='submit' class = 'Read_article_button'>Edit</button></div>
                                </form>

                                <form id = '$article_id' action='Delete-article.php' method='post'>
                                    <input name = 'Article_id' type='text' style= 'display: none' value = '$article_id'>
                                    <div><button onclick='clicked(event)' class = 'Read_article_button' >Delete</button></div>
                                </form>
                                
                                <script>
                                    function clicked(e)
                                    {
                                        if(!confirm('This will permanently delete the article.')) {
                                            e.preventDefault();
                                            document.getelementbyid('$article_id').submit();
                                        }
                                    }
                                </script>
                                
                            </div>
                        </div>";  
                    }
                }

                

 
                ?>
            </section>
        </section>

        <footer>
            <div class="footer-container">
              <nav class="footer-left">
                <ul>
                  <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
                </ul>
              </nav>
              <div class="footer-right">
                <p>© 2024 Help+</p>
                <a href="about-page.php">Credits</a>
              </div>
            </div>
        </footer>
	</body>
</html>