<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    include 'connect-database.php';
    
    $id = $_POST["Article_id"];

    $sql = "DELETE FROM articles WHERE article_id = ?";
    $statement = $pdo->prepare($sql);
    $statement->execute([$id]);

        session_start();
        $_SESSION["status"] = "<script>alert('Article successfully removed.');</script>";
        header("Location: My_articles.php");
        exit;
    
}