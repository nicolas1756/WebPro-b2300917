<?php

session_start();

if (isset($_SESSION['status'])) { //send error message
  echo $_SESSION['status'];
  unset($_SESSION['status']);
}

if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}

if ($user_role != "@%^198278ADm1n!@#$*" and $user_role != "$$66^^D0cT0R&&77"){ //value for if an account is an admin or doctor
    session_start();
    $_SESSION["status"] = "<script>alert('Account does not meet required security clearance.');</script>";
    header("Location: Home.php");
    exit;
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,minimum-scale=1">
		<title>Profile</title>
        <script type = "text/javascript" src="add-textArea.js"></script> 
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
		<link href="colour.css" rel="stylesheet" type="text/css">
	</head>
	<body>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
        <section class="menu">
            <div class="menu-container">  
                <nav class="navbar">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li class="highlighted-menu"><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </nav>
                
                <nav class="Profile" href="profile.php">
                    <a href="profile.php" class="sign-in" ><?=$user_name?></a>
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                </nav>
            </div>
            
            <div class="menu-container-mobile"> 
                <div class = "pop-out-menu">
                    <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                </div>
                
                <div>
                    <nav class="Profile-mobile" href="profile.php">
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                    </nav>
                </div>
            </div>

            <div id ="fix-sidebar">
              <div id = "sidebar-menu">
                    <ul>
                        <li><a href="Home.php">Home</a></li>
                        <li class="highlighted-menu"><a href="Health information.html">Health information</a></li>
                        <li><a href="Forum.html">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
            
        </section>

		<section class="margin">
            <?php
            if (isset($_SESSION['Edit_article'])) 
            { 
            $Edit_article_ID = $_SESSION['Edit_article_ID'];
            echo "<form id ='New_post' action='update-article.php' method='post'>
                    <input id = 'transferName' name = 'transferName' type='text' style= 'display: none'>
                    <input id = 'transferValue' name = 'transferValue' type='text' style= 'display: none'>
                    <input id = 'transferID' name = 'transferID' type='text' style= 'display: none' value = '$Edit_article_ID'>
                </form>";
            }

            else
            {
                echo '<form id ="New_post" action="Add-article.php" method="post">
                    <input id = "transferName" name = "transferName" type="text" style= "display: none">
                    <input id = "transferValue" name = "transferValue" type="text" style= "display: none">
                </form>';
            }
            
            ?>

            

                <div class = "add-article-option-container">
                    <div class = "add-article-button-container">
                        <div><button class = "Add-article-button" id="Exit_Write_article" onclick="if (confirm('This will delete the draft. Would you still like to proceed?')) { window.history.back(); } return false;">Exit</button></div>
                        <div><button class = "Add-article-button" id="add_title">Title</button></div>
                        <div><button class = "Add-article-button" id="add_h1">H1</button></div>
                        <div><button class = "Add-article-button" id="add_h2">H2</button></div>
                        <div><button class = "Add-article-button" id="add_h3">H3</button></div>
                        <div><button class = "Add-article-button" id="add_body">Body</button></div>
                        <div><button class = "Add-article-button" id="delete" onclick="deleteTextArea()">Delete</button></div>
                    </div>

                    <div>
                        <div class = "Publish-article-button_container"><button class = "Add-article-button" onclick="Format_article()">Publish</button></div>
                    </div>
                </div>


            <div id="Articlecontainer">
                <?php
                    if (isset($_SESSION['Edit_article'])) { /*if editing existing article*/
                        
                        $article = $_SESSION['Edit_article'];
                        $Edit_article_ID = $_SESSION['Edit_article_ID'];
                        include 'decode_article.php';
                        
                        $count = 0;
                        foreach ($content as $index => $Body) {
                            $Body = explode("<br>", $Body);
                            $Body = implode("\n", $Body);
                            if ($count == 0){
                                echo "<textarea name='$Format[$index]' id= 'Title_mandatory' class='Title' >$Body</textarea>";
                                $count += 1;
                                continue;
                            }
                            echo "<textarea name='$Format[$index]' class='$Format[$index]'>$Body</textarea>";
                        }
                    }

                    else{
                        echo '<textarea name="Title" id= "Title_mandatory" class="Title" placeholder = "Start writing here..."></textarea>';
                    }
                ?>
                <script>
                     textAreaSettings() /*format text areas generated by existing article*/
                </script>
                
            </div>

            <script>
                function deleteTextArea() {
                    const parentElement = document.getElementById("Articlecontainer");
                    const lastChild = parentElement.lastChild; // Get the last child
                    if (lastChild.id != 'Title_mandatory'){ // check if it is the required title
                        parentElement.removeChild(lastChild); // Remove the last child
                    }
                         
                    else{
                        alert("This title is mandatory and can't be deleted.")
                    }
                }
            </script>

            <script>
                title_counter = 0;
                h1_counter = 0;
                h2_counter = 0;
                h3_counter = 0;
                Body_counter = 0;
                const add_title = document.getElementById("add_title");
                const add_h1 = document.getElementById("add_h1");
                const add_h2 = document.getElementById("add_h2");
                const add_h3 = document.getElementById("add_h3");
                const add_body = document.getElementById("add_body");
                const Articlecontainer = document.getElementById("Articlecontainer");

                add_title.addEventListener("click", function() {
                    title = document.createElement("textarea");
                    title.name = "Title";
                    title.className = "Title";
                    title.placeholder = "Write title here";
                    title.rows = 1; 
                    Articlecontainer.appendChild(title);
                    title.form = "New_post";
                    textAreaSettings()
                    title_counter += 1;
                });

                add_h1.addEventListener("click", function() {
                    h1 = document.createElement("textarea");
                    h1.name = "H1";
                    h1.className = "H1";
                    h1.placeholder = "Write Heading 1 here";
                    h1.rows = 1; 
                    Articlecontainer.appendChild(h1);
                    h1.form = "New_post";
                    textAreaSettings()
                    h1_counter += 1;
                });

                add_h2.addEventListener("click", function() {
                    h2 = document.createElement("textarea");
                    h2.name = "H2";
                    h2.className = "H2";
                    h2.placeholder = "Write Heading 2 here";
                    h2.rows = 1; 
                    Articlecontainer.appendChild(h2);
                    h2.form = "New_post";
                    textAreaSettings()
                    h2_counter += 1;
                });

                add_h3.addEventListener("click", function() {
                    h3 = document.createElement("textarea");
                    h3.name = "H3";
                    h3.className = "H3";
                    h3.placeholder = "Write Heading 3 here";
                    h3.rows = 1; 
                    Articlecontainer.appendChild(h3);
                    h3.form = "New_post";
                    textAreaSettings()
                    h3_counter += 1;
                });
                

                add_body.addEventListener("click", function() {
                    Body = document.createElement("textarea");
                    Body.name = "body";
                    Body.className = "body";
                    Body.placeholder = "Write body here";
                    Body.rows = 1; 
                    Articlecontainer.appendChild(Body);
                    Body.form = "New_post";
                    textAreaSettings()
                    Body_counter += 1;
                });
                
            </script>

            <script>
                
                function Format_article(){

                    var nameValues = []; 
                    var values = [];  

                    var transferArticle = document.getElementById("transfer_article");
                    var articleContainer = document.getElementById("Articlecontainer"); 

                    
                    var elements = articleContainer.querySelectorAll("textarea");

                    elements.forEach(element => {
                        var name = element.getAttribute('name');
                        var value = element.value;

                        nameValues.push(name);
                        values.push(value);
                    });

                    transferName.value = nameValues;
                    transferValue.value = values.join("!!&&^#&&^^.!").split("\n").join("<br>");; //puts name and value of text area in order to post to php for processing
                    document.getElementById("New_post").submit();

                }

            </script>

        </section>


        <footer>
            <div class="footer-container">
              <nav class="footer-left">
                <ul>
                  <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
                </ul>
              </nav>
              <div class="footer-right">
                <p>© 2024 Help+</p>
                <?php 
                    if ($user_role == "@%^198278ADm1n!@#$*"){
                        echo "<a href='admin-panel.php'>Admin Menu</a><br>";
                    }
                ?>
                <a href="about-page.php">Credits</a>
              </div>
            </div>
        </footer>
	</body>
</html>