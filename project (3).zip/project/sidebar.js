
function sidebar() {
    const menu = document.getElementById('sidebar-menu');
    const img = document.getElementById('menu-icon-mobile');
    menu.style.display = menu.style.display === 'none' ? 'flex' : 'none';
}