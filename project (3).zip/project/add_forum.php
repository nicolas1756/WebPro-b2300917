<?php

    session_start();
    include 'connect-database.php';
    include 'get-profile-data.php';

    $UserId = $user_id;
    date_default_timezone_set('Asia/Kuala_Lumpur');
    $DatePublished = date('Y-m-d H:i:s'); 
    $Header = $_POST['Title'];
    $Body = $_POST['body'];

    $content = "$Header!$$*$%%.$$Body";

    $stmt = $pdo->prepare('INSERT INTO posts (user_id, date_published, content) VALUES (?, ?, ?)');
    $stmt->execute([$UserId, $DatePublished, $content]);
  
    
    if ($rowsAffected === 0) {
      session_start();
      $_SESSION["status"] = "<script>alert('post was not added. Please try again.');</script>";
      header("Location: Forum.php");
      exit;
    } else {
        session_start();
        $_SESSION["status"] = "<script>alert('post successfully added.');</script>";
        header("Location: Forum.php");
        exit;
    }
?>