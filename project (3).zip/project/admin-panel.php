<?php

session_start();

if (isset($_SESSION['status'])) { //send error message
  echo $_SESSION['status'];
  unset($_SESSION['status']);
}

if (isset($_SESSION['google_loggedin'])) {
  include 'get-profile-data.php';
}
else{
  $user_name = 'Sign in';
  $user_picture = 'Images\Profile picture.png';
  $user_role = "unregistered";
}

if ($user_role != "@%^198278ADm1n!@#$*"){ //value for if an account is an admin
    session_start();
    $_SESSION["status"] = "<script>alert('Account does not meet required security clearance.');</script>";
    header("Location: Home.php");
    exit;
}
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Help+</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type = "text/javascript" src="sidebar.js"></script>  
        <link href="colour_mandatory.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="colour.css">
    </head>

    <header class="Header">
        <a href="Home.php"><img src="Images\Logo.png" class="Header_logo"></a>
    </header>

    <body>
        <section class="menu">
            <div class="menu-container">  
                
                <nav class="navbar">
                    <ul>
                        
                      <li><a href="Home.php">Home</a></li>
                      <li><a href="Health-information.php">Health information</a></li>
                      <li><a href="Forum.php">Forum</a></li>
                      <li><a href="Newsletter.php">Newsletter</a></li>
                      <li><a href="about-page.php">About us</a></li>
                    </ul>
                </nav>
                
                <nav class="Profile" href="profile.php">
                    <a href="profile.php" class="sign-in" ><?=$user_name?></a>
                    <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                </nav>

            </div>

            <div class="menu-container-mobile"> 
                  <div class = "pop-out-menu">
                      <img id = "menu-icon-mobile" onclick="sidebar()" src="Images\burger-menu.png" />
                  </div>
                  
                  <div>
                      <nav class="Profile-mobile" href="profile.php">
                      <a href="profile.php"><img src="<?=$user_picture?>" class="profile-pic"></a>
                      </nav>
                  </div>
              </div>

              <div id ="fix-sidebar">
              <div id = "sidebar-menu">
                    <ul>
                        <li class="highlighted-menu"><a href="Home.php">Home</a></li>
                        <li><a href="Health-information.php">Health information</a></li>
                        <li><a href="Forum.php">Forum</a></li>
                        <li><a href="Newsletter.php">Newsletter</a></li>
                        <li><a href="about-page.php">About us</a></li>
                    </ul>
                </div>
            </div>
        </section>


        <section class="margin">
          
            <section class = "Remove-doctors">
              <div class = 'option-drop'>
                <img id = "img-remove-doctor" onclick="javascript:Expend_remove_doctor()" src="Images\white-down-arrow-png-2.png" /> Remove doctor
              </div>
              <script>
                function Expend_remove_doctor() {
                  const img = document.getElementById('img-remove-doctor');
                  const form = document.getElementById('remove_doctor_section');
                  form.style.display = form.style.display === 'none' ? 'block' : 'none';
                }
              </script>

              <section id = "remove_doctor_section">
                <?php
                  
                  include 'connect-database.php';

                  $sql = $pdo->prepare('SELECT email, name, id FROM accounts WHERE role = ? ORDER BY name asc');
                  $sql->execute(['$$66^^D0cT0R&&77']);
                  $doctor_data = $sql->fetchall(PDO::FETCH_ASSOC);

                  foreach ($doctor_data as $doctor) {
                    $doctor_email = $doctor['email'];
                    $doctor_name = $doctor['name'];
                    $doctor_id = $doctor['id'];
                    
                    echo " 
                    <ul>
                      <form action='remove-doctor.php' method = 'POST'>
                        <div class = 'remove-doctor-container'>
                          <div><label for='doctor_name'>$doctor_name [$doctor_email]</label></div>
                          <input type='text' name='doctor_id' value = '$doctor_id' style = 'display: none''>
                          <div><button id = 'remove_doctor' type='submit'>Remove</button></div>
                        </div>
                      </form>
                    </ul>";
                  }

                  if (empty($doctor_data)) {
                    echo " 
                    <ul>
                      <p style = 'margin: 0px'>No doctors added</p>
                    </ul>";
                  }
                ?>
              </section>

              <section id = "remove_doctor_section">
                <?php
                  
                  include 'connect-database.php';

                  $sql = $pdo->prepare('SELECT email, name, id FROM accounts WHERE role = ? ORDER BY name asc');
                  $sql->execute(['$$66^^D0cT0R&&77']);
                  $doctor_data = $sql->fetchall(PDO::FETCH_ASSOC);

                  foreach ($doctor_data as $doctor) {
                    $doctor_email = $doctor['email'];
                    $doctor_name = $doctor['name'];
                    $doctor_id = $doctor['id'];
                    
                    echo " 
                    <ul>
                      <form action='remove-doctor.php' method = 'POST'>
                        <div class = 'remove-doctor-container'>
                          <div><label for='doctor_name'>$doctor_name [$doctor_email]</label></div>
                          <input type='text' name='doctor_id' value = '$doctor_id' style = 'display: none''>
                          <div><button id = 'remove_doctor' type='submit'>Remove</button></div>
                        </div>
                      </form>
                    </ul>";
                  }

                  if (empty($doctor_data)) {
                    echo " 
                    <ul>
                      <p style = 'margin: 0px'>No doctors added</p>
                    </ul>";
                  }
                ?>
              </section>
            
            </section>

            <section class = "Add-doctors">
              <div class = 'option-drop'>
                <img id = "img-add-doctor" onclick="javascript:Expend_add_doctor()" src="Images\white-down-arrow-png-2.png" /> Add doctor
              </div>
              <script>
                function Expend_add_doctor() {
                  const img = document.getElementById('img-add-doctor');
                  const form = document.getElementById('add_doctor_form');
                  form.style.display = form.style.display === 'none' ? 'block' : 'none';
                }
              </script>
              <form id = "add_doctor_form" action="add-doctor.php" method = "POST">
                  <ul>
                    <label for="Doctor-email">Enter doctor email: </label>
                    <input type="email" name="Doctor-email" value="" required>
                  </ul>

                  <ul class= "floor_container">
                    <label for="Doctor-floor">Enter room floor: </label><br>
                    <input type="radio" id = "Doctor-floor" name="Doctor-floor" value="G" required>G:
                    <input type="radio" id = "Doctor-floor" name="Doctor-floor" value="1" required>1:
                    <input type="radio" id = "Doctor-floor" name="Doctor-floor" value="2" required>2:
                    <input type="radio" id = "Doctor-floor" name="Doctor-floor" value="3" required>3:
                    <input type="radio" id = "Doctor-floor" name="Doctor-floor" value="4" required>4:
                    <input type="radio" id = "Doctor-floor" name="Doctor-floor" value="5" required>5:
                  </ul>
                  
                  <ul>
                    <label for="Doctor-number">Enter room number: </label>
                    <input type="text" name="Doctor-number" value="" required>
                  </ul>
                  
                  <section class = "doctor_specialization">
                      <ul><label for="doctor_specialization">Select a specialization:<br></label></ul>
                      <?php
                       
                        include 'connect-database.php';
                        
                        $Doctors = $pdo->prepare('SELECT Doctor_specialization FROM doctors GROUP BY Doctor_specialization');
                        $Doctors->execute();
                        $doctor_data = $Doctors->fetchAll(PDO::FETCH_ASSOC);
                        // Database connection and data retrieval (same as your provided code)
                        foreach ($doctor_data as $doctor) {
                            $doctor_specialization = $doctor['Doctor_specialization'];
                            echo " <ul><input type='radio' name='doctor_specialization' value='$doctor_specialization' required> <label for='doctor_specialization'>$doctor_specialization</label><br></ul>";
                        }
                      ?>
                      <ul class = "specialization_container">
                        <input type='radio' name='doctor_specialization' value='custom' id='custom' required> 
                        <label for='doctor_specialization'>Custom</label>
                        <input type="text" id="custom-text" name="doctor_specialization_custom" value="">
                      </ul>

                      <script>
                        const radioButtons = document.querySelectorAll('input[name="doctor_specialization"]');
                        const textBox = document.getElementById('custom-text');
                        textBox.style.display = 'none';
                        radioButtons.forEach(radioButton => {
                          radioButton.addEventListener('change', function() {
                            if (this.value === 'custom') { // Check for specific value
                              textBox.style.display = 'block';
                            } else {
                              textBox.style.display = 'none';
                            }
                          });
                        });
                      </script>
                  </section>
                  <div class= 'save-doctor-div'>
                    <input type="text" style = 'display: none'>
                    <button type="submit" id="save-doctor">Add</button>
                  </div>
                  
              </form>
            </section>

            <section class = "view_accounts">
              <div class = 'option-drop'>
                <img id = "img-view-accounts" onclick="javascript:Expend_view_accounts()" src="Images\white-down-arrow-png-2.png" /> View accounts
              </div>
              <script>
                function Expend_view_accounts() {
                  const img = document.getElementById('img-view-accounts');
                  const form = document.getElementById('view_account_section');
                  form.style.display = form.style.display === 'none' ? 'block' : 'none';
                }
              </script>

              <section id = "view_account_section">
                <?php
                  
                  include 'connect-database.php';

                  $sql = $pdo->prepare('SELECT email, role, id FROM accounts ORDER BY email asc');
                  $sql->execute([]);
                  $accounts = $sql->fetchall(PDO::FETCH_ASSOC);

                  foreach ($accounts as $account) {
                    $account_email = $account['email'];
                    $account_role = $account['role'];
                    $account_id = $account['id'];

                    if($account_role == "@%^198278ADm1n!@#$*"){
                      $account_role = "Admin";
                    }

                    if($account_role == "$$66^^D0cT0R&&77"){
                      $account_role = "Doctor";
                    }
                    
                    echo " 
                    <ul>
                      <form id = '$account_id' action='delete-account.php' method = 'POST'>
                        <div class = 'delete-account-container'>
                          <div><label for=''>$account_email [$account_role]</label></div>
                          <input type='text' name='account_id' value = '$account_id' style = 'display: none''>
                          <div><button id = 'delete_account' type='submit' onclick='clicked(event)'>Remove</button></div>
                        </div>
                      </form>
                    </ul>
                    
                    <script>
                        function clicked(e)
                        {
                            if(!confirm('This will permanently remove all data associated with the account.')) {
                                e.preventDefault();
                                document.getelementbyid('$account_id').submit();
                            }
                        }
                    </script>
                    ";
                  }

                  if (empty($accounts)) {
                    echo " 
                    <ul>
                      <p style = 'margin: 0px'>No accounts added</p>
                    </ul>";
                  }
                ?>
              </section>  
            </section>

            <section class = "view_admin">
              <div class = 'option-drop'>
                <img id = "img-add_admin" onclick="javascript:Expend_add_admin()" src="Images\white-down-arrow-png-2.png" /> Add admin
              </div>
              <script>
                function Expend_add_admin() {
                  const img = document.getElementById('img-add_admin');
                  const form = document.getElementById('add_admin_section');
                  form.style.display = form.style.display === 'none' ? 'block' : 'none';
                }
              </script>

              <section id = "add_admin_section">
                <?php
                  
                  include 'connect-database.php';

                  $sql = $pdo->prepare('SELECT email, role, id FROM accounts WHERE role = ?');
                  $sql->execute(['Standard']);
                  $accounts = $sql->fetchall(PDO::FETCH_ASSOC);

                  foreach ($accounts as $account) {
                    $account_email = $account['email'];
                    $account_id = $account['id'];
                    
                    echo " 
                    <ul>
                      <form id = '$account_id' action='add-admin.php' method = 'POST'>
                        <div class = 'delete-account-container'>
                          <div><label for=''>$account_email [id: $account_id]</label></div>
                          <input type='text' name='account_id' value = '$account_id' style = 'display: none''>
                          <div><button id = 'delete_account' type='submit' onclick=''>Add admin</button></div>
                        </div>
                      </form>
                    </ul>
                    ";
                  }

                  if (empty($accounts)) {
                    echo " 
                    <ul>
                      <p style = 'margin: 0px'>No accounts to add</p>
                    </ul>";
                  }
                ?>
              </section>  
            </section>

            <section class = "delete_admin">
              <div class = 'option-drop'>
                <img id = "img-remove_admin" onclick="javascript:Expend_remove_admin()" src="Images\white-down-arrow-png-2.png" /> Remove admin
              </div>
              <script>
                function Expend_remove_admin() {
                  const img = document.getElementById('img-remove_admin');
                  const form = document.getElementById('remove_admin_section');
                  form.style.display = form.style.display === 'none' ? 'block' : 'none';
                }
              </script>

              <section id = "remove_admin_section">
                <?php
                  
                  include 'connect-database.php';

                  $sql = $pdo->prepare('SELECT email, role, id FROM accounts WHERE role = ?');
                  $sql->execute(['@%^198278ADm1n!@#$*']);
                  $accounts = $sql->fetchall(PDO::FETCH_ASSOC);

                  foreach ($accounts as $account) {
                    $account_email = $account['email'];
                    $account_id = $account['id'];
                    
                    echo " 
                    <ul>
                      <form id = '$account_id' action='remove-admin.php' method = 'POST'>
                        <div class = 'delete-account-container'>
                          <div><label for=''>$account_email [id: $account_id]</label></div>
                          <input type='text' name='account_id' value = '$account_id' style = 'display: none''>
                          <div><button id = 'delete_account' type='submit' onclick=''>Remove admin</button></div>
                        </div>
                      </form>
                    </ul>
                    ";
                  }

                  if (empty($accounts)) {
                    echo " 
                    <ul>
                      <p style = 'margin: 0px'>No accounts to add</p>
                    </ul>";
                  }
                ?>
              </section>  
            </section>

        </section>

        <footer>
            <div class="footer-container">
              <nav class="footer-left">
                <ul>
                  <li><a href="Home.php"><img src="Images\Logo.png" alt="Company Logo" class="footer-logo"></a></li>
                </ul>
              </nav>
              <div class="footer-right">
                <p>© 2024 Help+</p>
                <a href='https://analytics.google.com/analytics/web/?authuser=0#/a320589707p448839429/admin' target='_blank' rel='noopener noreferrer'>Analytics Dashboard</a><br>
                <a href="about-page.php">Credits</a>
              </div>
            </div>
          </footer>
          
          
    </body> 
</html>