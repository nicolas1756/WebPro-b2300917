<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    function debug_to_console($data) {
        $output = $data;
        if (is_array($output))
            $output = implode(',', $output);
    
        echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
    }
    
    include 'connect-database.php';
    
    $email = $_POST["Doctor-email"];
    $floor = $_POST["Doctor-floor"];
    $room_number = $_POST["Doctor-number"];
    $specialization = $_POST["doctor_specialization"];

    $room_location = ($floor.".".$room_number);

    if ($specialization == 'custom'){
        $specialization = $_POST["doctor_specialization_custom"];
    }

    if (strlen(intval($room_number)) == 2){

        $sql = $pdo->prepare('SELECT id, name FROM accounts WHERE email = ?');
        $sql->execute([$email]);
        $account_details = $sql->fetch(PDO::FETCH_ASSOC);

        $id = $account_details['id'];

        if ($id == "") {
            session_start();
            $_SESSION["status"] = "<script>alert('Account not found. Please try again.');</script>";
            header("Location: admin-panel.php");
            exit;
        }

        else{
            $stmt = $pdo->prepare('INSERT INTO doctors (Doctor_location, Doctor_specialization, user_id) VALUES (?, ?, ?)');
            $stmt->execute([$room_location, $specialization, $id]);

            $sql = "UPDATE accounts SET role = ? WHERE id = ?";
            $statement = $pdo->prepare($sql);
            $statement->execute(["$$66^^D0cT0R&&77", $id]);


            session_start();
            $_SESSION["status"] = "<script>alert('doctor successfully added.');</script>";
            header("Location: admin-panel.php");
            exit;
            
        }
           
    }

    else{
        session_start();
        $_SESSION["status"] = "<script>alert('invalid room number format. Ensure room number entered is 2 digits long and an integer.');</script>";
        header("Location: admin-panel.php");
        exit;
    }
    

}