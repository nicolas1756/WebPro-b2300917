<?php

    session_start();
    include 'connect-database.php';
    include 'get-profile-data.php';

    $post_id = $_POST['post_id'];
    $UserId = $user_id;
    date_default_timezone_set('Asia/Kuala_Lumpur');
    $DatePublished = date('Y-m-d H:i:s'); 
    $Body = $_POST['body'];

    $stmt = $pdo->prepare('INSERT INTO post_comments (user_id, date_published, content, post_id) VALUES (?, ?, ?, ?)');
    $stmt->execute([$UserId, $DatePublished, $Body, $post_id]);
  
    $_SESSION["status"] = "<script>alert('comment successfully added.');</script>";

    echo"
    <form action='View_forum_post.php' id = 'form' method = 'post'>
        <input type='text' name='post_id' value = '$post_id' style = 'display:none'>
    </form>
    
    <script>
      document.getElementById('form').submit();
    </script>
    ";
    
?>